chrome.runtime.onMessage.addListener(async (request, sender, sendResponse) => {
    if (request.action === 'setIcon') {
        try {
            const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
            
            if (request.animate) {
                // 设置动态效果
                const normalIcon = {
                    tabId: tab.id,
                    path: {
                        "19": "icons/button_19x19.png",
                        "38": "icons/button_38x38.png"
                    }
                };
                const starIcon = {
                    tabId: tab.id,
                    path: request.icon
                };
                
                // 创建动画效果
                let isStarShowing = false;
                const interval = setInterval(() => {
                    chrome.action.setIcon(isStarShowing ? normalIcon : starIcon);
                    isStarShowing = !isStarShowing;
                }, 600);
                
                // 3秒后停止动画并保持星标图标
                setTimeout(() => {
                    clearInterval(interval);
                    chrome.action.setIcon(starIcon);
                }, 3000);
            } else {
                await chrome.action.setIcon({
                    tabId: tab.id,
                    path: request.icon
                });
            }
            
            sendResponse({ success: true });
        } catch (error) {
            console.error('设置图标失败:', error);
            sendResponse({ success: false, error: error.message });
        }
    }
    return true; // 保持消息通道开放以支持异步响应
});