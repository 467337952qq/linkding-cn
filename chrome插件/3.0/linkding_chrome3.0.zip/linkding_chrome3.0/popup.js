// 全局变量
let currentUrl = '';
let currentTitle = '';
let existingBookmarkId = null; // 存储已存在书签的 ID
let tagFrequencyMap = new Map(); // 存储标签使用频率

// =====================
// 公共工具函数
// =====================

// 获取配置
async function getConfig() {
  return new Promise((resolve) => {
    chrome.storage.sync.get({
      baseUrl: '',
      apiToken: '',
      defaultTags: '',
      defaultUnread: true,
      defaultShared: false,
      enableBookmarkComparison: false,
      quickTagCount: 3,
      quickTags: '',
      enableTagRecommend: false,
      recommendTags: ''
    }, (items) => {
      resolve(items);
    });
  });
}

// 显示消息 toast
function showMessage(message, type = 'success') {
  // 移除已有的 toast
  document.querySelectorAll('.toast-msg').forEach(el => el.remove());
  const messageEl = document.createElement('div');
  messageEl.textContent = message;
  messageEl.className = `${type} toast-msg`;
  document.body.insertBefore(messageEl, document.body.firstChild);
  setTimeout(() => messageEl.remove(), 3000);
}

// 获取页面 meta description（公共函数，消除重复代码）
async function fetchPageDescription() {
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    // chrome:// / edge:// 等内部页面无法注入脚本，静默跳过
    if (!tab?.url || /^(chrome|edge|about|data):/.test(tab.url)) return '';
    const results = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      function: () => {
        const metaDesc = document.querySelector('meta[name="description"]')?.content || '';
        const firstParagraph = metaDesc || document.querySelector('p')?.textContent || '';
        return firstParagraph.trim().substring(0, 500);
      }
    });
    return results?.[0]?.result || '';
  } catch (error) {
    console.error('获取描述失败:', error);
    return '';
  }
}

// =====================
// 书签检测（使用官方 /check/ 接口）
// =====================

// 使用 /check/ 接口检查 URL 是否已存在书签
async function checkExistingBookmark(url, config) {
  if (!config.baseUrl || !config.apiToken) return null;
  try {
    const baseUrl = config.baseUrl.replace(/\/$/, '');
    const response = await fetch(`${baseUrl}/api/bookmarks/check/?url=${encodeURIComponent(url)}`, {
      headers: {
        'Authorization': `Token ${config.apiToken}`,
        'Content-Type': 'application/json'
      }
    });
    if (!response.ok) {
      throw new Error(`HTTP错误 ${response.status}`);
    }
    const data = await response.json();
    // 更新图标
    const iconElement = document.getElementById('bookmarkIcon');
    if (data.bookmark) {
      iconElement.src = 'icons/button_19x19_star.png';
    } else {
      iconElement.src = 'icons/button_19x19.png';
    }
    return data.bookmark || null; // 返回已存在的书签对象，或 null
  } catch (error) {
    console.error('检查书签失败:', error);
    const iconElement = document.getElementById('bookmarkIcon');
    if (iconElement) iconElement.src = 'icons/button_19x19.png';
    return null;
  }
}

// =====================
// 初始化流程
// =====================

// 获取当前标签页信息，并根据结果填充表单
async function getCurrentTab() {
  chrome.tabs.query({ active: true, currentWindow: true }, async function(tabs) {
    currentUrl = tabs[0].url;
    currentTitle = tabs[0].title;
    document.getElementById('url').value = currentUrl;

    const config = await getConfig();

    if (config.enableBookmarkComparison) {
      // 使用 /check/ 接口检测重复书签
      const existingBookmark = await checkExistingBookmark(currentUrl, config);
      if (existingBookmark) {
        existingBookmarkId = existingBookmark.id;
        syncBookmarkToForm(existingBookmark);
        // 先拉标签列表，再初始化快捷按钮
        await initTagsAutocomplete();
        initQuickTagBtns(existingBookmark.tag_names || []);
        initRecommendTagBtns(document.getElementById('tags').value);
      } else {
        existingBookmarkId = null;
        document.getElementById('title').value = currentTitle;
        const desc = await fetchPageDescription();
        if (desc) document.getElementById('descInput').value = desc;
        // 应用默认标签（仅新书签时）
        if (config.defaultTags) {
          document.getElementById('tags').value = config.defaultTags;
        }
        // 先拉标签列表，再初始化快捷按钮
        await initTagsAutocomplete();
        initQuickTagBtns(null);
        initRecommendTagBtns(document.getElementById('tags').value);
      }
    } else {
      existingBookmarkId = null;
      document.getElementById('title').value = currentTitle;
      const desc = await fetchPageDescription();
      if (desc) document.getElementById('descInput').value = desc;
      // 先拉标签列表，再初始化快捷按钮
      await initTagsAutocomplete();
      initQuickTagBtns(null);
      initRecommendTagBtns(document.getElementById('tags').value);
    }
  });
}

// 初始化函数
async function init() {
  getCurrentTab();

  const config = await getConfig();

  // 应用默认已读状态
  if (config.defaultUnread) {
    document.querySelector('input[name="readStatus"][value="unread"]').checked = true;
  } else {
    document.querySelector('input[name="readStatus"][value="read"]').checked = true;
  }
  document.querySelector('input[name="shared"]').checked = config.defaultShared;

  // 绑定导航事件
  document.getElementById('openSite').addEventListener('click', openSite);
  document.getElementById('settings').addEventListener('click', () => {
    chrome.runtime.openOptionsPage();
  });

  // 绑定选项卡切换
  document.querySelector('.tab-switch').addEventListener('click', handleTabSwitch);

  // 绑定表单提交
  document.getElementById('bookmarkForm').addEventListener('submit', saveBookmark);
}

// =====================
// 交互事件
// =====================

// 打开 Linkding 网站
async function openSite() {
  const config = await getConfig();
  if (config.baseUrl) {
    chrome.tabs.create({ url: config.baseUrl });
  } else {
    showMessage('请先在设置中配置服务器地址', 'error');
  }
}

// 将已有书签数据同步到表单
function syncBookmarkToForm(bookmark) {
  document.getElementById('title').value = bookmark.title;
  document.getElementById('descInput').value = bookmark.description || '';
  document.getElementById('noteInput').value = bookmark.notes || '';

  // 笔记 tab 有内容时显示提示
  const noteTab = document.querySelector('.tab[data-type="note"]');
  noteTab.textContent = '笔记';
  if (bookmark.notes) {
    const hasNoteSpan = document.createElement('span');
    hasNoteSpan.textContent = ' (有笔记)';
    hasNoteSpan.style.color = '#1a73e8';
    noteTab.appendChild(hasNoteSpan);
  }

  document.getElementById('tags').value = bookmark.tag_names.join(' ');
  document.querySelector(`input[name="readStatus"][value="${bookmark.unread ? 'unread' : 'read'}"]`).checked = true;
  document.querySelector('input[name="shared"]').checked = bookmark.shared;

  // 显示 URL 已存在提示
  document.getElementById('urlTip').style.display = 'block';

  // 设置星标图标（精简为一条消息）
  chrome.runtime.sendMessage({
    action: 'setIcon',
    icon: {
      "19": "icons/button_19x19_star.png",
      "38": "icons/button_38x38_star.png"
    },
    animate: true
  }, response => {
    if (!response?.success) {
      console.error('设置图标失败:', response?.error);
    }
  });
}

// 处理描述/笔记选项卡切换
function handleTabSwitch(event) {
  const button = event.target;
  if (!button.matches('.tab')) return;

  document.querySelectorAll('.tab').forEach(tab => tab.classList.remove('active'));
  button.classList.add('active');

  const type = button.dataset.type;
  document.querySelectorAll('.content').forEach(content => content.classList.remove('active'));
  document.getElementById(type).classList.add('active');
  document.getElementById(type + 'Input').focus();
}

// =====================
// 保存书签
// =====================

async function saveBookmark(e) {
  e.preventDefault();

  const config = await getConfig();
  if (!config.baseUrl || !config.apiToken) {
    showMessage('请先在设置中配置Base URL和API Token', 'error');
    return;
  }

  const submitBtn = document.querySelector('.submit-btn');
  submitBtn.disabled = true;
  submitBtn.textContent = '保存中...';

  const baseUrl = config.baseUrl.replace(/\/$/, '');
  const data = {
    url: document.getElementById('url').value,
    title: document.getElementById('title').value,
    description: document.getElementById('descInput').value,
    notes: document.getElementById('noteInput').value,
    tag_names: document.getElementById('tags').value
      .split(/[,\s]/)
      .map(tag => tag.trim())
      .filter(tag => tag),
    unread: document.querySelector('input[name="readStatus"]:checked').value === 'unread',
    shared: document.querySelector('input[name="shared"]').checked
  };

  try {
    // POST 接口在 URL 已存在时会静默更新，无需手动判断
    const response = await fetch(`${baseUrl}/api/bookmarks/`, {
      method: 'POST',
      headers: {
        'Authorization': `Token ${config.apiToken}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(data)
    });

    if (!response.ok) {
      let errorMessage;
      try {
        const errorData = await response.json();
        errorMessage = errorData.detail || errorData.message || `HTTP错误 ${response.status}`;
      } catch (e) {
        errorMessage = `服务器错误 (${response.status})`;
      }
      throw new Error(errorMessage);
    }

    showMessage('书签保存成功！');
    setTimeout(() => window.close(), 1000);
  } catch (error) {
    console.error('保存失败:', error);
    showMessage(`保存失败：${error.message}`, 'error');
    submitBtn.disabled = false;
    submitBtn.textContent = '提交';
  }
}

// =====================
// 标签自动完成
// =====================

async function initTagsAutocomplete() {
  const config = await getConfig();
  if (!config.baseUrl || !config.apiToken) return;

  await fetchAllTags(config);

  const tagsInput = document.getElementById('tags');
  const tagSuggestions = document.getElementById('tagSuggestions');

  tagsInput.addEventListener('input', () => {
    const lastTag = getLastTag(tagsInput.value);
    if (lastTag.trim() !== '') {
      filterTagSuggestions(lastTag);
    } else {
      tagSuggestions.style.display = 'none';
    }
  });

  tagsInput.addEventListener('blur', () => {
    setTimeout(() => { tagSuggestions.style.display = 'none'; }, 200);
  });

  tagsInput.addEventListener('focus', () => {
    const lastTag = getLastTag(tagsInput.value);
    if (lastTag.trim() !== '') {
      filterTagSuggestions(lastTag);
    }
  });
}

// 获取所有标签及使用频率
async function fetchAllTags(config) {
  try {
    const baseUrl = config.baseUrl.replace(/\/$/, '');
    const response = await fetch(`${baseUrl}/api/tags/?limit=1000`, {
      headers: {
        'Authorization': `Token ${config.apiToken}`,
        'Content-Type': 'application/json'
      }
    });
    if (!response.ok) throw new Error(`HTTP错误 ${response.status}`);
    const data = await response.json();
    tagFrequencyMap.clear();
    data.results.forEach(tag => {
      tagFrequencyMap.set(tag.name, tag.bookmark_count || 0);
    });
    console.log('已加载标签数量:', tagFrequencyMap.size);
  } catch (error) {
    console.error('获取标签失败:', error);
  }
}

// 显示所有标签（按频率排序）
function showTagSuggestions() {
  const tagSuggestions = document.getElementById('tagSuggestions');
  tagSuggestions.innerHTML = '';
  if (tagFrequencyMap.size === 0) {
    tagSuggestions.style.display = 'none';
    return;
  }
  const sortedTags = Array.from(tagFrequencyMap.entries())
    .sort((a, b) => b[1] - a[1])
    .slice(0, 20)
    .map(entry => entry[0]);
  sortedTags.forEach(tag => tagSuggestions.appendChild(createTagElement(tag)));
  tagSuggestions.style.display = 'block';
}

// 根据输入过滤标签
function filterTagSuggestions(input) {
  const tagSuggestions = document.getElementById('tagSuggestions');
  tagSuggestions.innerHTML = '';
  if (tagFrequencyMap.size === 0 || !input.trim()) {
    tagSuggestions.style.display = 'none';
    return;
  }
  const lowerInput = input.toLowerCase();
  const filteredTags = Array.from(tagFrequencyMap.entries())
    .filter(([tag]) => tag.toLowerCase().includes(lowerInput))
    .sort((a, b) => b[1] - a[1])
    .slice(0, 10)
    .map(entry => entry[0]);
  if (filteredTags.length === 0) {
    tagSuggestions.style.display = 'none';
    return;
  }
  filteredTags.forEach(tag => tagSuggestions.appendChild(createTagElement(tag)));
  tagSuggestions.style.display = 'block';
}

// 创建标签建议元素
function createTagElement(tag) {
  const tagElement = document.createElement('div');
  tagElement.className = 'tag-suggestion';
  tagElement.textContent = tag;
  tagElement.title = `使用次数: ${tagFrequencyMap.get(tag) || 0}`;
  tagElement.addEventListener('click', () => selectTag(tag));
  return tagElement;
}

// 获取最后一个正在输入的标签
function getLastTag(inputValue) {
  const tags = inputValue.split(/[,\s]/);
  return tags[tags.length - 1];
}

// 选择标签
function selectTag(tag) {
  const tagsInput = document.getElementById('tags');
  const currentValue = tagsInput.value;
  if (!currentValue.trim()) {
    tagsInput.value = tag;
  } else {
    const tags = currentValue.split(/[,\s]/);
    tags.pop();
    tagsInput.value = tags.length > 0 ? tags.join(' ') + ' ' + tag : tag;
  }
  document.getElementById('tagSuggestions').style.display = 'none';
  tagsInput.focus();
}

// =====================
// 快捷标签按钮
// =====================

// 初始化快捷标签（existingTags: 旧书签已有标签数组，传 null 表示新书签）
async function initQuickTagBtns(existingTags) {
  const config = await getConfig();
  const container = document.getElementById('quickTagBtns');
  container.innerHTML = '';

  const maxCount = Math.max(1, Math.min(10, config.quickTagCount || 3));

  // 所有标签（直接取名字，排序交给 appendTagDropdown 统一处理）
  const allTopTags = Array.from(tagFrequencyMap.keys());

  if (existingTags && existingTags.length > 0) {
    // 旧书签：原有标签显示为按钮（默认选中），最多 maxCount 个
    const btnTags = existingTags.slice(0, maxCount);
    btnTags.forEach(tag => {
      const btn = document.createElement('button');
      btn.type = 'button';
      btn.className = 'quick-tag-btn selected';
      btn.textContent = tag;
      btn.dataset.tag = tag;
      btn.addEventListener('click', () => toggleQuickTag(btn));
      container.appendChild(btn);
    });

    // 补充：常用标签下拉框（排除已有标签）
    const existingSet = new Set(existingTags);
    const dropdownTags = allTopTags.filter(t => !existingSet.has(t));
    if (dropdownTags.length > 0) {
      appendTagDropdown(container, dropdownTags);
    }
  } else {
    // 新书签：优先用设置里配置的固定标签作为按钮
    const fixed = (config.quickTags || '')
      .split(/[\s,]+/)
      .map(t => t.trim())
      .filter(t => t)
      .slice(0, maxCount);

    fixed.forEach(tag => {
      const btn = document.createElement('button');
      btn.type = 'button';
      btn.className = 'quick-tag-btn';
      btn.textContent = tag;
      btn.dataset.tag = tag;
      btn.addEventListener('click', () => toggleQuickTag(btn));
      container.appendChild(btn);
    });

    // 补充：常用标签下拉框（排除固定标签）
    const fixedSet = new Set(fixed);
    const dropdownTags = allTopTags.filter(t => !fixedSet.has(t));
    if (dropdownTags.length > 0) {
      appendTagDropdown(container, dropdownTags);
    }
  }
}

// 创建常用标签下拉框并追加到容器
function appendTagDropdown(container, tags) {
  const select = document.createElement('select');
  select.className = 'quick-tag-select';

  const placeholder = document.createElement('option');
  placeholder.value = '';
  placeholder.textContent = '+ 更多标签';
  placeholder.disabled = true;
  placeholder.selected = true;
  select.appendChild(placeholder);

  // 排序：字母/数字在前（A-Z），中文在后（按拼音）
  const sortedTags = [...tags].sort((a, b) => {
    const aLower = a.toLowerCase();
    const bLower = b.toLowerCase();
    const aIsAscii = /^[a-z0-9]/.test(aLower);
    const bIsAscii = /^[a-z0-9]/.test(bLower);
    // 字母/数字优先于中文
    if (aIsAscii && !bIsAscii) return -1;
    if (!aIsAscii && bIsAscii) return 1;
    // 同类型时按字母/拼音排序
    return aLower.localeCompare(bLower);
  });

  sortedTags.forEach(tag => {
    const opt = document.createElement('option');
    opt.value = tag;
    opt.textContent = tag;
    select.appendChild(opt);
  });

  select.addEventListener('change', () => {
    const tag = select.value;
    if (!tag) return;
    const tagsInput = document.getElementById('tags');
    const current = tagsInput.value
      .split(/[\s,]+/)
      .map(t => t.trim())
      .filter(t => t);
    if (!current.includes(tag)) {
      current.push(tag);
      tagsInput.value = current.join(' ');
    }
    // 重置下拉框
    select.value = '';
  });

  container.appendChild(select);
}

// =====================
// 推荐标签
// =====================

// 从中文文本中提取所有 2 字及以上的子串（滑动窗口）
function extractChineseNgrams(text, minLen = 2, maxLen = 6) {
  const words = [];
  // 先用空白/标点分割成词段
  const segments = text.split(/[\s\-\/·|—·,，。！？、【】「」《》""'']+/).filter(s => s.length >= minLen);
  for (const seg of segments) {
    // 对每个词段滑动提取 n-gram
    for (let len = minLen; len <= Math.min(maxLen, seg.length); len++) {
      for (let i = 0; i <= seg.length - len; i++) {
        words.push(seg.slice(i, i + len));
      }
    }
  }
  return words;
}

// 根据标题和描述，与已有标签做关键词匹配，返回推荐标签数组
function getSmartRecommendTags(title, desc, existingTagSet) {
  const text = (title + ' ' + desc).toLowerCase();
  const recommended = [];

  // 从标题/描述里提取关键词（中文 n-gram + 英文单词）
  const textNgrams = new Set(extractChineseNgrams(text));
  // 英文单词也加进去
  const enWords = text.match(/[a-z0-9]{2,}/g) || [];
  enWords.forEach(w => textNgrams.add(w));

  for (const tag of tagFrequencyMap.keys()) {
    if (existingTagSet.has(tag)) continue; // 已选中的跳过
    const tagLower = tag.toLowerCase();

    // 方向1：标签名整体出现在文本里（原逻辑，兼容英文标签）
    if (text.includes(tagLower)) {
      recommended.push(tag);
      continue;
    }

    // 方向2：文本里的 n-gram 关键词出现在标签名里（例："书签" 匹配 "书签类开发"）
    let matched = false;
    for (const ngram of textNgrams) {
      if (ngram.length >= 2 && tagLower.includes(ngram)) {
        matched = true;
        break;
      }
    }
    if (matched) {
      recommended.push(tag);
      continue;
    }

    // 方向3：标签名的任意 2字+ 子串出现在文本里（例："开发" 出现在描述里）
    const tagNgrams = extractChineseNgrams(tagLower, 2, 4);
    for (const ng of tagNgrams) {
      if (text.includes(ng)) {
        matched = true;
        break;
      }
    }
    if (matched) {
      recommended.push(tag);
    }
  }
  return recommended;
}

// 初始化推荐标签区域
async function initRecommendTagBtns(currentTagsInInput) {
  const config = await getConfig();
  const wrapper = document.getElementById('recommendTagBtns');

  if (!config.enableTagRecommend) {
    wrapper.style.display = 'none';
    return;
  }

  const listEl = wrapper.querySelector('.recommend-tag-list');
  listEl.innerHTML = '';

  // 当前输入框已有的标签（用于排除）
  const inputTagSet = new Set(
    (currentTagsInInput || '').split(/[\s,]+/).map(t => t.trim()).filter(t => t)
  );

  // 1. 固定推荐标签（设置里配置的）
  const fixedTags = (config.recommendTags || '')
    .split(/[\s,]+/)
    .map(t => t.trim())
    .filter(t => t);

  // 2. 智能匹配标签（根据标题+描述）
  const title = document.getElementById('title')?.value || '';
  const desc = document.getElementById('descInput')?.value || '';
  const smartTags = getSmartRecommendTags(title, desc, inputTagSet);

  // 合并：固定在前，智能补充（去重），排除已在输入框里的
  const allRecommend = [...new Set([...fixedTags, ...smartTags])]
    .filter(t => !inputTagSet.has(t));

  if (allRecommend.length === 0) {
    wrapper.style.display = 'none';
    return;
  }

  allRecommend.forEach(tag => {
    const btn = document.createElement('button');
    btn.type = 'button';
    btn.className = 'recommend-tag-btn';
    btn.textContent = tag;
    btn.dataset.tag = tag;
    btn.addEventListener('click', () => {
      // 点击后加入标签输入框，并移除该按钮
      const tagsInput = document.getElementById('tags');
      const current = tagsInput.value.split(/[\s,]+/).map(t => t.trim()).filter(t => t);
      if (!current.includes(tag)) {
        current.push(tag);
        tagsInput.value = current.join(' ');
      }
      btn.remove();
      // 如果没有推荐了，隐藏整行
      if (listEl.children.length === 0) {
        wrapper.style.display = 'none';
      }
    });
    listEl.appendChild(btn);
  });

  wrapper.style.display = 'flex';
}

// 点击快捷标签按钮：切换选中/取消
function toggleQuickTag(btn) {
  const tag = btn.dataset.tag;
  const tagsInput = document.getElementById('tags');
  const isSelected = btn.classList.contains('selected');

  if (isSelected) {
    // 取消选中：从输入框移除该标签
    btn.classList.remove('selected');
    const current = tagsInput.value
      .split(/[\s,]+/)
      .map(t => t.trim())
      .filter(t => t && t !== tag);
    tagsInput.value = current.join(' ');
  } else {
    // 选中：追加到输入框（避免重复）
    btn.classList.add('selected');
    const current = tagsInput.value
      .split(/[\s,]+/)
      .map(t => t.trim())
      .filter(t => t);
    if (!current.includes(tag)) {
      current.push(tag);
      tagsInput.value = current.join(' ');
    }
  }
}

// =====================
// 启动
// =====================
document.addEventListener('DOMContentLoaded', init);
