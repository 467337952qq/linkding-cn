// Linkding Extension Options Bundle

// Browser compatibility layer
function getBrowser() {
  if (typeof chrome !== 'undefined' && chrome.runtime) {
    return chrome;
  }
  if (typeof browser !== 'undefined' && browser.runtime) {
    return browser;
  }
  return null;
}

function getStorage() {
  const browserAPI = getBrowser();
  return browserAPI ? browserAPI.storage.local : null;
}

// Configuration management
const CONFIG_KEY = "ld_ext_config";

const DEFAULT_CONFIG = {
  baseUrl: "",
  token: "",
  resultNum: 10,
  openLinkType: "newTab",
  themeGoogle: "auto",
  themeDuckduckgo: "auto",
  themeBrave: "auto",
  themeSearx: "auto",
  themeKagi: "auto",
  themeQwant: "auto",
  themeBaidu: "auto",
  themeBing: "auto",
};

async function getConfiguration() {
  return new Promise((resolve) => {
    getStorage().get(CONFIG_KEY, (data) => {
      try {
        const config = JSON.parse(data[CONFIG_KEY]);
        resolve(config);
      } catch {
        const config = DEFAULT_CONFIG;
        resolve(config);
      }
    });
  });
}

function saveConfiguration(config) {
  const configJson = JSON.stringify(config);
  getStorage().set({ [CONFIG_KEY]: configJson });
}

// Linkding API
class LinkdingApi {
  constructor(config) {
    this.config = config;
  }

  async testConnection() {
    try {
      const response = await fetch(`${this.config.baseUrl}/api/bookmarks/`, {
        method: 'GET',
        headers: {
          'Authorization': `Token ${this.config.token}`,
          'Content-Type': 'application/json'
        }
      });
      return response.ok;
    } catch (error) {
      console.error('Connection test failed:', error);
      return false;
    }
  }
}

// Options component
class Options {
  constructor(options) {
    this.target = options.target;
    this.config = {};
    this.isSuccess = false;
    this.isError = false;
    this.init();
  }

  async init() {
    this.config = await getConfiguration();
    this.render();
    this.bindEvents();
  }

  render() {
    this.target.innerHTML = `
      <div class="container">
        <h6>配置</h6>
        <div class="divider"></div>
        <p>
          这是 
          <a href="https://github.com/sissbruecker/linkding">linkding</a>
          书签服务的配套扩展程序。在开始使用之前，您需要配置一些基本设置，以便扩展程序能够与您的 linkding 安装进行通信。
        </p>
        
        <form class="form" id="config-form">
          <div class="form-group">
            <label class="form-label" for="input-base-url">
              Base URL <span class="text-error">*</span>
            </label>
            <input
              class="form-input"
              type="text"
              id="input-base-url"
              placeholder="https://linkding.mydomain.com"
              value="${this.config.baseUrl || ''}"
            />
            <div class="form-input-hint">
              The base URL of your linkding installation, <b>without</b> the
              <samp>/bookmark</samp> path or a trailing slash
            </div>
          </div>
          
          <div class="form-group">
            <label class="form-label" for="input-token">
              API 身份验证令牌 <span class="text-error">*</span>
            </label>
            <input
              class="form-input"
              type="password"
              id="input-token"
              placeholder="令牌"
              value="${this.config.token || ''}"
            />
            <div class="form-input-hint">
              用于对 linkding API 进行身份验证。您可以在 linkding 设置页面中找到此令牌。
            </div>
          </div>
          
          <div class="form-group">
            <label class="form-label" for="input-search-num">
              搜索结果的最大数量
            </label>
            <input
              class="form-input"
              type="number"
              id="input-search-num"
              placeholder="10"
              value="${this.config.resultNum || 10}"
            />
            <div class="form-input-hint">
              搜索结果的最大数量。数量过多可能导致性能下降。
            </div>
          </div>
          
          <div class="accordion">
            <input type="checkbox" id="accordion-1" name="accordion-checkbox" hidden />
            <label class="accordion-header" for="accordion-1">
              <i class="icon icon-arrow-right mr-1"></i>
              高级设置
            </label>
            <div class="accordion-body">
              <div class="form-group">
                <div class="form-label">默认链接打开方式</div>
                <label class="form-radio">
                  <input
                    type="radio"
                    name="openLinkType"
                    value="newTab"
                    ${this.config.openLinkType === 'newTab' ? 'checked' : ''}
                  />
                  <i class="form-icon"></i>在新标签页中打开链接（默认）
                </label>
                <label class="form-radio">
                  <input
                    type="radio"
                    name="openLinkType"
                    value="sameTab"
                    ${this.config.openLinkType === 'sameTab' ? 'checked' : ''}
                  />
                  <i class="form-icon"></i>在同一标签页中打开链接
                </label>
              </div>
              
              ${this.renderThemeSettings()}
            </div>
          </div>
          
          <div class="divider"></div>
          
          <div class="button-row">
            ${this.isSuccess ? '<div class="form-group has-success mr-2"><span class="form-input-hint"><i class="icon icon-check"></i> 连接成功</span></div>' : ''}
            ${this.isError ? '<div class="form-group has-error mr-2"><span class="form-input-hint"><i class="icon icon-cross"></i> 连接失败</span></div>' : ''}
            <button type="submit" class="btn btn-primary ml-2" id="save-btn">
              保存
            </button>
          </div>
        </form>
      </div>
    `;
  }

  renderThemeSettings() {
    const engines = [
      { key: 'themeGoogle', label: 'Google' },
      { key: 'themeDuckduckgo', label: 'DuckDuckGo' },
      { key: 'themeBrave', label: 'Brave Search†' },
      { key: 'themeSearx', label: 'SearX/SearXNG†' },
      { key: 'themeKagi', label: 'Kagi Search' },
      { key: 'themeQwant', label: 'Qwant' },
      { key: 'themeBaidu', label: '百度' },
      { key: 'themeBing', label: '必应' }
    ];

    return engines.map(engine => `
      <div class="form-group p-relative clearfix">
        <div class="form-label float-left">${engine.label}</div>
        <label class="form-radio form-inline float-right">
          <input type="radio" name="${engine.key}" value="light" ${this.config[engine.key] === 'light' ? 'checked' : ''} />
          <i class="form-icon"></i>浅色
        </label>
        <label class="form-radio form-inline float-right">
          <input type="radio" name="${engine.key}" value="dark" ${this.config[engine.key] === 'dark' ? 'checked' : ''} />
          <i class="form-icon"></i>深色
        </label>
        <label class="form-radio form-inline float-right">
          <input type="radio" name="${engine.key}" value="auto" ${this.config[engine.key] === 'auto' || !this.config[engine.key] ? 'checked' : ''} />
          <i class="form-icon"></i>自动（默认）
        </label>
      </div>
    `).join('') + `
      <div class="form-input-hint">
        † 除非您在搜索引擎设置中设置特定主题（非"系统"），否则这些搜索引擎的自动主题检测可能会失败。
      </div>
    `;
  }

  bindEvents() {
    const form = document.getElementById('config-form');
    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      await this.handleSubmit();
    });
  }

  async handleSubmit() {
    const baseUrl = document.getElementById('input-base-url').value;
    const token = document.getElementById('input-token').value;
    const resultNum = parseInt(document.getElementById('input-search-num').value) || 10;
    
    const openLinkType = document.querySelector('input[name="openLinkType"]:checked')?.value || 'newTab';
    
    const config = {
      baseUrl,
      token,
      resultNum,
      openLinkType,
      themeGoogle: document.querySelector('input[name="themeGoogle"]:checked')?.value || 'auto',
      themeDuckduckgo: document.querySelector('input[name="themeDuckduckgo"]:checked')?.value || 'auto',
      themeBrave: document.querySelector('input[name="themeBrave"]:checked')?.value || 'auto',
      themeSearx: document.querySelector('input[name="themeSearx"]:checked')?.value || 'auto',
      themeKagi: document.querySelector('input[name="themeKagi"]:checked')?.value || 'auto',
      themeQwant: document.querySelector('input[name="themeQwant"]:checked')?.value || 'auto',
      themeBaidu: document.querySelector('input[name="themeBaidu"]:checked')?.value || 'auto',
      themeBing: document.querySelector('input[name="themeBing"]:checked')?.value || 'auto',
    };

    const testResult = await new LinkdingApi(config).testConnection();

    if (testResult) {
      await saveConfiguration(config);
      this.isError = false;
      this.isSuccess = true;
    } else {
      this.isSuccess = false;
      this.isError = true;
    }
    
    this.render();
    this.bindEvents();
  }
}

// Export for global use
window.linkding = {
  Options
};