<script>
  import { getConfiguration, saveConfiguration } from "./configuration";
  import { LinkdingApi } from "./linkding";

  let baseUrl;
  let token;
  let resultNum;
  let openLinkType;
  let themeDuckduckgo;
  let themeGoogle;
  let themeBrave;
  let themeSearx;
  let themeKagi;
  let themeQwant;
  let isSuccess;
  let isError;

  async function init() {
    const config = await getConfiguration();
    baseUrl = config.baseUrl;
    token = config.token;
    resultNum = config.resultNum;
    openLinkType = config.openLinkType;
    themeDuckduckgo = config.themeDuckduckgo;
    themeGoogle = config.themeGoogle;
    themeBrave = config.themeBrave;
    themeSearx = config.themeSearx;
    themeKagi = config.themeKagi;
    themeQwant = config.themeQwant;
  }

  init();

  async function handleSubmit() {
    const config = {
      baseUrl,
      token,
      resultNum,
      openLinkType,
      themeDuckduckgo,
      themeGoogle,
      themeBrave,
      themeSearx,
      themeKagi,
      themeQwant,
    };

    const testResult = await new LinkdingApi(config).testConnection(config);

    if (testResult) {
      await saveConfiguration(config);
      isError = false;
      isSuccess = true;
    } else {
      isSuccess = false;
      isError = true;
    }
  }
</script>

<h6>配置</h6>
<div class="divider" />
<p>
  这是 <a
    href="https://github.com/sissbruecker/linkding">linkding</a
  > 书签服务的配套扩展程序。在开始使用之前，您需要配置一些基本设置，以便扩展程序能够与您的 linkding 安装进行通信。
</p>
<form class="form" on:submit|preventDefault={handleSubmit}>
  <div class="form-group">
    <label class="form-label" for="input-base-url"
      >基础 URL <span class="text-error">*</span></label
    >
    <input
      class="form-input"
      type="text"
      id="input-base-url"
      placeholder="https://linkding.mydomain.com"
      bind:value={baseUrl}
    />
    <div class="form-input-hint">
      您的 linkding 安装的基础 URL，<b>不包含</b>
      <samp>/bookmark</samp> 路径或尾部斜杠
    </div>
  </div>
  <div class="form-group">
    <label class="form-label" for="input-token"
      >API 认证令牌 <span class="text-error">*</span></label
    >
    <input
      class="form-input"
      type="password"
      id="input-token"
      placeholder="Token"
      bind:value={token}
    />
    <div class="form-input-hint">
      用于对 linkding API 进行身份验证。您可以在 linkding 设置页面中找到此令牌。
    </div>
  </div>
  <div class="form-group">
    <label class="form-label" for="input-search-num"
      >搜索结果最大数量
    </label>
    <input
      class="form-input"
      type="number"
      id="input-search-num"
      placeholder="10"
      bind:value={resultNum}
    />
    <div class="form-input-hint">
      搜索结果的最大数量。数量过多可能导致性能下降。
    </div>
  </div>
  <div class="accordion">
    <input type="checkbox" id="accordion-1" name="accordion-checkbox" hidden />
    <label class="accordion-header" for="accordion-1">
      <i class="icon icon-arrow-right mr-1" />
      高级设置
    </label>
    <div class="accordion-body">
      <div class="form-group">
        <div class="form-label">默认链接打开方式</div>
        <label class="form-radio">
          <input
            type="radio"
            id="input-link-type"
            bind:group={openLinkType}
            value="newTab"
          />
          <i class="form-icon" />在新标签页中打开链接（默认）
        </label>
        <label class="form-radio">
          <input
            type="radio"
            id="input-link-type"
            bind:group={openLinkType}
            value="sameTab"
          />
          <i class="form-icon" />在当前标签页中打开链接
        </label>
      </div>
      <div class="form-group p-relative clearfix">
        <div class="form-label">注入框主题</div>
        <div class="form-label float-left">google</div>
        <label class="form-radio form-inline float-right">
          <input
            type="radio"
            id="google-light"
            bind:group={themeGoogle}
            value="light"
          />
          <i class="form-icon" />浅色
        </label>
        <label class="form-radio form-inline float-right">
          <input
            type="radio"
            id="google-dark"
            bind:group={themeGoogle}
            value="dark"
          />
          <i class="form-icon" />深色
        </label>
        <label class="form-radio form-inline float-right">
          <input
            type="radio"
            id="google-auto"
            bind:group={themeGoogle}
            value="auto"
          />
          <i class="form-icon" />自动（默认）
        </label>
      </div>
      <div class="form-group p-relative clearfix">
        <div class="form-label float-left">DuckDuckGo</div>
        <label class="form-radio form-inline float-right">
          <input type="radio" bind:group={themeDuckduckgo} value="light" />
          <i class="form-icon" />浅色
        </label>
        <label class="form-radio form-inline float-right">
          <input type="radio" bind:group={themeDuckduckgo} value="dark" />
          <i class="form-icon" />深色
        </label>
        <label class="form-radio form-inline float-right">
          <input type="radio" bind:group={themeDuckduckgo} value="auto" />
          <i class="form-icon" />自动（默认）
        </label>
      </div>
      <div class="form-group p-relative clearfix">
        <div class="form-label float-left">Brave Search†</div>
        <label class="form-radio form-inline float-right">
          <input type="radio" bind:group={themeBrave} value="light" />
          <i class="form-icon" />浅色
        </label>
        <label class="form-radio form-inline float-right">
          <input type="radio" bind:group={themeBrave} value="dark" />
          <i class="form-icon" />深色
        </label>
        <label class="form-radio form-inline float-right">
          <input type="radio" bind:group={themeBrave} value="auto" />
          <i class="form-icon" />自动（默认）
        </label>
      </div>
      <div class="form-group p-relative clearfix">
        <div class="form-label float-left">SearX/SearXNG†</div>
        <label class="form-radio form-inline float-right">
          <input type="radio" bind:group={themeSearx} value="light" />
          <i class="form-icon" />浅色
        </label>
        <label class="form-radio form-inline float-right">
          <input type="radio" bind:group={themeSearx} value="dark" />
          <i class="form-icon" />深色
        </label>
        <label class="form-radio form-inline float-right">
          <input type="radio" bind:group={themeSearx} value="auto" />
          <i class="form-icon" />自动（默认）
        </label>
      </div>
      <div class="form-group p-relative clearfix">
        <div class="form-label float-left">Kagi Search</div>
        <label class="form-radio form-inline float-right">
          <input type="radio" bind:group={themeKagi} value="light" />
          <i class="form-icon" />浅色
        </label>
        <label class="form-radio form-inline float-right">
          <input type="radio" bind:group={themeKagi} value="dark" />
          <i class="form-icon" />深色
        </label>
        <label class="form-radio form-inline float-right">
          <input type="radio" bind:group={themeKagi} value="auto" />
          <i class="form-icon" />自动（默认）
        </label>
      </div>
      <div class="form-group p-relative clearfix">
        <div class="form-label float-left">Qwant</div>
        <label class="form-radio form-inline float-right">
          <input type="radio" bind:group={themeQwant} value="light" />
          <i class="form-icon" />浅色
        </label>
        <label class="form-radio form-inline float-right">
          <input type="radio" bind:group={themeQwant} value="dark" />
          <i class="form-icon" />深色
        </label>
        <label class="form-radio form-inline float-right">
          <input type="radio" bind:group={themeQwant} value="auto" />
          <i class="form-icon" />自动（默认）
        </label>
      </div>
      <div class="form-input-hint">
        † 除非您在搜索引擎设置中设置特定主题（非"系统"），否则这些搜索引擎的自动主题检测可能会失败。
      </div>
    </div>
  </div>

  <div class="divider" />

  <div class="button-row">
    {#if isSuccess}
      <div class="form-group has-success mr-2">
        <span class="form-input-hint"
          ><i class="icon icon-check" /> 连接成功
        </span>
      </div>
    {/if}
    {#if isError}
      <div class="form-group has-error mr-2">
        <span class="form-input-hint">
          <i class="icon icon-cross" /> 连接失败
        </span>
      </div>
    {/if}
    <button
      type="submit"
      class="btn btn-primary ml-2"
      disabled={!(baseUrl && token)}
    >
      保存
    </button>
  </div>
</form>

<style>
  .button-row {
    display: flex;
    justify-content: flex-end;
    align-items: baseline;
  }
  .button-row button {
    padding-left: 32px;
    padding-right: 32px;
  }
</style>
