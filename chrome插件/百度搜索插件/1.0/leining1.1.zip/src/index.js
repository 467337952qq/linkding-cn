import Options from "./options.svelte";

export default {
  Options,
};
