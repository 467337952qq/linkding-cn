# Chrome Extension Version

这个文件夹包含了适用于Chrome浏览器的linkding injector扩展文件。

## 文件结构

- `manifest.json` - Chrome Manifest V3格式的配置文件
- `options/` - 扩展选项页面文件
- `icons/` - 扩展图标文件
- `src/` - 源代码文件
- `styles/` - 样式文件
- `build/` - 构建后的文件（需要运行构建命令生成）

## 安装方法

1. 首先在项目根目录运行构建命令：
   ```bash
   npm install
   npm run build
   ```

2. 打开Chrome浏览器，进入扩展管理页面：
   - 地址栏输入 `chrome://extensions/`
   - 或者通过菜单：更多工具 → 扩展程序

3. 开启"开发者模式"（右上角开关）

4. 点击"加载已解压的扩展程序"

5. 选择这个 `web` 文件夹

6. 扩展将被加载到Chrome中

## 与Firefox版本的区别

- 使用Manifest V3格式（Chrome要求）
- `background.scripts` 改为 `background.service_worker`
- `permissions` 分离为 `permissions` 和 `host_permissions`
- `web_accessible_resources` 格式更新

## 注意事项

- 确保已经构建了项目，`build/` 文件夹中包含必要的JavaScript和CSS文件
- 如果修改了源代码，需要重新构建并在Chrome中重新加载扩展