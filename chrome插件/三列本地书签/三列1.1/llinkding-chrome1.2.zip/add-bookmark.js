// 添加书签功能的脚本

document.addEventListener('DOMContentLoaded', function() {
  // DOM元素
  const urlInput = document.getElementById('url');
  const titleInput = document.getElementById('title');
  const descriptionInput = document.getElementById('description');
  const tagsInput = document.getElementById('tags');
  const unreadCheckbox = document.getElementById('unread');
  const addBookmarkBtn = document.getElementById('addBookmarkBtn');
  const statusMessage = document.getElementById('statusMessage');
  
  // 获取当前活动标签页的信息
  chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
    if (tabs && tabs.length > 0) {
      const currentTab = tabs[0];
      urlInput.value = currentTab.url;
      titleInput.value = currentTab.title;
      
      // 获取页面描述（如果可能）
      chrome.scripting.executeScript({
        target: {tabId: currentTab.id},
        function: getPageDescription
      }, function(results) {
        if (results && results[0] && results[0].result) {
          descriptionInput.value = results[0].result;
        }
      });
    }
  });
  
  // 添加书签按钮点击事件
  addBookmarkBtn.addEventListener('click', function() {
    // 验证URL
    const url = urlInput.value.trim();
    if (!url) {
      showStatus('请输入URL', 'error');
      return;
    }
    
    // 准备书签数据
    const bookmarkData = {
      url: url,
      title: titleInput.value.trim(),
      description: descriptionInput.value.trim(),
      tag_names: tagsInput.value.split(',').map(tag => tag.trim()).filter(tag => tag),
      unread: unreadCheckbox.checked
    };
    
    // 获取API设置
    chrome.storage.sync.get(['serverUrl', 'apiToken'], function(items) {
      if (!items.serverUrl || !items.apiToken) {
        showStatus('请先在设置页面配置服务器信息', 'error');
        return;
      }
      
      // 发送API请求
      const apiUrl = new URL('/api/bookmarks/', items.serverUrl).href;
      
      fetch(apiUrl, {
        method: 'POST',
        headers: {
          'Authorization': 'Token ' + items.apiToken,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(bookmarkData)
      })
      .then(response => {
        if (!response.ok) {
          throw new Error('API请求失败: ' + response.status);
        }
        return response.json();
      })
      .then(data => {
        showStatus('书签添加成功', 'success');
        
        // 清空表单或关闭窗口
        setTimeout(function() {
          window.close();
        }, 1500);
      })
      .catch(error => {
        console.error('添加书签失败:', error);
        showStatus('添加书签失败: ' + error.message, 'error');
      });
    });
  });
  
  // 显示状态消息
  function showStatus(message, type) {
    statusMessage.textContent = message;
    statusMessage.className = 'status ' + type;
    statusMessage.classList.remove('hidden');
  }
});

// 获取页面描述的函数（在页面上下文中执行）
function getPageDescription() {
  // 尝试获取meta description
  const metaDesc = document.querySelector('meta[name="description"]');
  if (metaDesc && metaDesc.content) {
    return metaDesc.content;
  }
  
  // 尝试获取第一段落文本
  const firstParagraph = document.querySelector('p');
  if (firstParagraph && firstParagraph.textContent) {
    return firstParagraph.textContent.trim().substring(0, 200);
  }
  
  return '';
}