// 全局变量
let currentUrl = '';
let currentTitle = '';
let tagFrequencyMap = new Map(); // 存储标签使用频率

// 获取当前标签页信息
function getCurrentTab() {
  chrome.tabs.query({active: true, currentWindow: true}, async function(tabs) {
    currentUrl = tabs[0].url;
    currentTitle = tabs[0].title;
    document.getElementById('url').value = currentUrl;

    // 检查是否启用了书签对比
    const config = await getConfig();
    if (config.enableBookmarkComparison) {
      const existingBookmark = await findExistingBookmark(currentUrl, config);
      if (existingBookmark) {
        syncBookmarkToForm(existingBookmark);
        // 移除这行提示信息
        // showMessage('已找到相同网址的书签，已自动同步信息', 'success');
      } else {
        document.getElementById('title').value = currentTitle;
        // 获取页面描述
        try {
          const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
          const results = await chrome.scripting.executeScript({
            target: { tabId: tab.id },
            function: () => {
              // 尝试获取 meta description
              const metaDesc = document.querySelector('meta[name="description"]')?.content || '';
              // 如果没有 meta description，获取第一段文本
              const firstParagraph = metaDesc || document.querySelector('p')?.textContent || '';
              return firstParagraph.trim().substring(0, 500); // 限制长度
            }
          });
          if (results && results[0]?.result) {
            document.getElementById('descInput').value = results[0].result;
          }
        } catch (error) {
          console.error('获取描述失败:', error);
        }
      }
    } else {
      document.getElementById('title').value = currentTitle;
      // 获取页面描述
      try {
        const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
        const results = await chrome.scripting.executeScript({
          target: { tabId: tab.id },
          function: () => {
            // 尝试获取 meta description
            const metaDesc = document.querySelector('meta[name="description"]')?.content || '';
            // 如果没有 meta description，获取第一段文本
            const firstParagraph = metaDesc || document.querySelector('p')?.textContent || '';
            return firstParagraph.trim().substring(0, 500); // 限制长度
          }
        });
        if (results && results[0]?.result) {
          document.getElementById('descInput').value = results[0].result;
        }
      } catch (error) {
        console.error('获取描述失败:', error);
      }
    }
    
    // 初始化标签自动完成功能
    initTagsAutocomplete();
  });
}

// 初始化函数
async function init() {
  // 获取当前标签页信息
  getCurrentTab();

  // 获取并应用默认设置
  const config = await getConfig();
  // 显示配置的 URL 并检查 API 连接状态
  const configuredUrlElement = document.getElementById('configuredUrl');
  if (config.baseUrl && configuredUrlElement) {
    configuredUrlElement.textContent = config.baseUrl.replace(/^https?:\/\//, '');
    configuredUrlElement.title = config.baseUrl; // 鼠标悬停时显示完整URL
    checkApiConnection(config, configuredUrlElement);
    configuredUrlElement.addEventListener('click', () => {
      if (config.baseUrl) {
        chrome.tabs.create({ url: config.baseUrl });
      }
    });
    configuredUrlElement.style.cursor = 'pointer'; // 添加手型光标
  }
  if (config.defaultUnread) {
    document.querySelector('input[name="readStatus"][value="unread"]').checked = true;
  } else {
    document.querySelector('input[name="readStatus"][value="read"]').checked = true;
  }
  document.querySelector('input[name="shared"]').checked = config.defaultShared;

  // 修改默认标签的应用逻辑：只在没有找到现有书签时应用默认标签
  const existingBookmark = await findExistingBookmark(currentUrl, config);
  if (!existingBookmark && config.defaultTags) {
    document.getElementById('tags').value = config.defaultTags;
  }

  // 绑定导航事件
  document.getElementById('openSite').addEventListener('click', openSite);
  document.getElementById('openLocalHomepage').addEventListener('click', () => {
    chrome.tabs.create({ url: chrome.runtime.getURL('homepage.html') });
  });
  document.getElementById('settings').addEventListener('click', () => {
    chrome.runtime.openOptionsPage();
  });

  // 绑定选项卡切换事件
  const tabSwitch = document.querySelector('.tab-switch');
  tabSwitch.addEventListener('click', handleTabSwitch);

  // 绑定表单提交事件
  document.getElementById('bookmarkForm').addEventListener('submit', saveBookmark);
}

// 打开网站
async function openSite() {
  const config = await getConfig();
  if (config.baseUrl) {
    chrome.tabs.create({ url: config.baseUrl });
  } else {
    showMessage('请先在设置中配置服务器地址', 'error');
  }
}

// 获取配置
async function getConfig() {
  return new Promise((resolve) => {
    chrome.storage.sync.get({
      baseUrl: '',
      apiToken: '',
      defaultTags: '',
      defaultUnread: true,
      defaultShared: false,
      enableBookmarkComparison: false
    }, (items) => {
      resolve(items);
    });
  });
}

// 查找现有书签
async function findExistingBookmark(url, config) {
    try {
        const response = await fetch(`${config.baseUrl}/api/bookmarks/?q=${encodeURIComponent(url)}`, {
            headers: {
                'Authorization': `Token ${config.apiToken}`,
                'Content-Type': 'application/json'
            }
        });

        if (!response.ok) {
            throw new Error(`HTTP错误 ${response.status}`);
        }

        const data = await response.json();
        // 精确匹配 URL
        const existingBookmark = data.results.find(bookmark => bookmark.url === url);
        
        // 根据是否存在书签来更改图标
        const iconElement = document.getElementById('bookmarkIcon');
        if (existingBookmark) {
            iconElement.src = 'icons/button_19x19_star.png';
        } else {
            iconElement.src = 'icons/button_19x19.png';
        }
        
        return existingBookmark;
    } catch (error) {
        console.error('查找书签失败:', error);
        // 发生错误时显示默认图标
        const iconElement = document.getElementById('bookmarkIcon');
        iconElement.src = 'icons/button_19x19.png';
        return null;
    }
}

// 同步书签信息到表单
function syncBookmarkToForm(bookmark) {
  document.getElementById('title').value = bookmark.title;
  document.getElementById('descInput').value = bookmark.description || '';
  document.getElementById('noteInput').value = bookmark.notes || '';
  
  // 如果有笔记内容，在笔记按钮旁显示"有笔记"提示
  const noteTab = document.querySelector('.tab[data-type="note"]');
  if (bookmark.notes) {
      const hasNoteSpan = document.createElement('span');
      hasNoteSpan.textContent = ' (有笔记)';
      hasNoteSpan.style.color = '#1a73e8';
      noteTab.textContent = '笔记';
      noteTab.appendChild(hasNoteSpan);
  } else {
      noteTab.textContent = '笔记';
  }
  
  document.getElementById('tags').value = bookmark.tag_names.join(' '); // 使用空格分隔标签
  document.querySelector('input[name="readStatus"][value="' + (bookmark.unread ? 'unread' : 'read') + '"]').checked = true;
  document.querySelector('input[name="shared"]').checked = bookmark.shared;
  
  // 显示 URL 已存在的提示信息
  document.getElementById('urlTip').style.display = 'block';
  
  // 发送消息给 background 开启动态图标
  chrome.runtime.sendMessage({
    action: 'setIcon',
    icon: {
      "19": "icons/button_19x19.png",
      "38": "icons/button_38x38.png"
    },
    animate: true
  }, response => {
    if (!response?.success) {
      console.error('设置动态图标失败:', response?.error);
    }
  });
    // 设置带星标的图标
    chrome.runtime.sendMessage({
      action: 'setIcon',
      icon: {
        "19": "icons/button_19x19_star.png",
        "38": "icons/button_38x38_star.png"
      }
    }, response => {
      if (!response?.success) {
        console.error('设置图标失败:', response?.error);
      }
    });
}

// 显示消息
function showMessage(message, type = 'success') {
  const messageEl = document.createElement('div');
  messageEl.textContent = message;
  messageEl.className = type;
  document.body.insertBefore(messageEl, document.body.firstChild);
  setTimeout(() => messageEl.remove(), 3000);
}

// 处理选项卡切换
function handleTabSwitch(event) {
  const button = event.target;
  if (!button.matches('.tab')) return;

  // 更新按钮状态
  const tabs = document.querySelectorAll('.tab');
  tabs.forEach(tab => tab.classList.remove('active'));
  button.classList.add('active');

  // 更新内容区域
  const type = button.dataset.type;
  const contents = document.querySelectorAll('.content');
  contents.forEach(content => content.classList.remove('active'));
  document.getElementById(type).classList.add('active');

  // 聚焦到文本框
  document.getElementById(type + 'Input').focus();
}

// 保存书签
async function saveBookmark(e) {
  e.preventDefault();
  
  const config = await getConfig();
  if (!config.baseUrl || !config.apiToken) {
    showMessage('请先在设置中配置Base URL和API Token', 'error');
    return;
  }
  
  // 确保 baseUrl 没有结尾的斜杠
  const baseUrl = config.baseUrl.replace(/\/$/, '');
  
  const data = {
    url: document.getElementById('url').value,
    title: document.getElementById('title').value,
    description: document.getElementById('descInput').value,
    notes: document.getElementById('noteInput').value,
    tag_names: document.getElementById('tags').value
      .split(/[,\s]/) // 同时支持逗号和空格分隔
      .map(tag => tag.trim()) // 清理每个标签的首尾空白
      .filter(tag => tag), // 移除空标签
    unread: document.querySelector('input[name="readStatus"]:checked').value === 'unread',
    shared: document.querySelector('input[name="shared"]').checked
  };
  
  try {
    const response = await fetch(`${baseUrl}/api/bookmarks/`, {
      method: 'POST',
      headers: {
        'Authorization': `Token ${config.apiToken}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(data)
    });
    
    if (!response.ok) {
      let errorMessage;
      try {
        const errorData = await response.json();
        errorMessage = errorData.detail || errorData.message || `HTTP错误 ${response.status}`;
      } catch (e) {
        errorMessage = `服务器错误 (${response.status})`;
      }
      throw new Error(errorMessage);
    }
    
    showMessage('书签保存成功！');
    setTimeout(() => window.close(), 1000);
  } catch (error) {
    console.error('保存失败:', error);
    showMessage(`保存失败：${error.message}`, 'error');
  }
}

// 检查 API 连接状态并更新 UI
async function checkApiConnection(config, element) {
  if (!config.baseUrl || !config.apiToken) {
    element.style.color = 'red';
    element.title = config.baseUrl ? `${config.baseUrl} (API Token 未配置)` : '服务器地址未配置';
    return;
  }
  try {
    // 尝试访问一个需要认证的端点，例如 /api/tags/ ，如果配置了token，这个端点应该能正常返回
    // 如果只想检查网络连通性而不关心认证，可以尝试访问 /api/
    const cleanedBaseUrl = config.baseUrl.replace(/\/$/, ''); // 确保末尾没有斜杠
    const response = await fetch(`${cleanedBaseUrl}/api/tags/`, { // 使用 /api/tags/ 作为测试端点
      headers: {
        'Authorization': `Token ${config.apiToken}`
      }
    });
    if (response.ok) {
      element.style.color = 'green';
      element.title = `${config.baseUrl} (API 连接正常)`;
    } else {
      element.style.color = 'red';
      element.title = `${config.baseUrl} (API 连接失败: ${response.status})`;
    }
  } catch (error) {
    element.style.color = 'red';
    element.title = `${config.baseUrl} (API 连接错误: ${error.message})`;
    console.error('API 连接检查失败:', error);
  }
}

// 页面加载完成后初始化
document.addEventListener('DOMContentLoaded', init);

// 初始化标签自动完成功能
async function initTagsAutocomplete() {
  const config = await getConfig();
  if (!config.baseUrl || !config.apiToken) return;
  
  // 获取所有标签及其使用频率
  await fetchAllTags(config);
  
  const tagsInput = document.getElementById('tags');
  const tagSuggestions = document.getElementById('tagSuggestions');
  
  // 鼠标悬停时显示标签建议
  tagsInput.addEventListener('mouseenter', () => {
    if (tagsInput.value.trim() === '') {
      showTagSuggestions();
    }
  });
  
  // 输入时实时过滤标签
  tagsInput.addEventListener('input', () => {
    const inputValue = tagsInput.value;
    const lastTag = getLastTag(inputValue);
    
    if (lastTag.trim() !== '') {
      filterTagSuggestions(lastTag);
    } else {
      tagSuggestions.style.display = 'none';
    }
  });
  
  // 焦点离开时隐藏建议
  tagsInput.addEventListener('blur', (e) => {
    // 延迟隐藏，以便能够点击建议
    setTimeout(() => {
      tagSuggestions.style.display = 'none';
    }, 200);
  });
  
  // 焦点获取时显示建议
  tagsInput.addEventListener('focus', () => {
    const inputValue = tagsInput.value;
    const lastTag = getLastTag(inputValue);
    
    if (lastTag.trim() !== '') {
      filterTagSuggestions(lastTag);
    } else {
      showTagSuggestions();
    }
  });
}

// 获取所有标签及其使用频率
async function fetchAllTags(config) {
  try {
    const baseUrl = config.baseUrl.replace(/\/$/, '');
    const response = await fetch(`${baseUrl}/api/tags/?limit=1000`, {
      headers: {
        'Authorization': `Token ${config.apiToken}`,
        'Content-Type': 'application/json'
      }
    });
    
    if (!response.ok) {
      throw new Error(`HTTP错误 ${response.status}`);
    }
    
    const data = await response.json();
    
    // 清空现有的频率映射
    tagFrequencyMap.clear();
    
    // 填充标签频率映射
    data.results.forEach(tag => {
      tagFrequencyMap.set(tag.name, tag.bookmark_count || 0);
    });
    
    console.log('已加载标签数量:', tagFrequencyMap.size);
  } catch (error) {
    console.error('获取标签失败:', error);
  }
}

// 显示所有标签建议（按使用频率排序）
function showTagSuggestions() {
  const tagSuggestions = document.getElementById('tagSuggestions');
  tagSuggestions.innerHTML = '';
  
  if (tagFrequencyMap.size === 0) {
    tagSuggestions.style.display = 'none';
    return;
  }
  
  // 按使用频率排序标签
  const sortedTags = Array.from(tagFrequencyMap.entries())
    .sort((a, b) => b[1] - a[1]) // 按频率降序排序
    .map(entry => entry[0]);
  
  // 最多显示前20个标签
  const tagsToShow = sortedTags.slice(0, 20);
  
  tagsToShow.forEach(tag => {
    const tagElement = createTagElement(tag);
    tagSuggestions.appendChild(tagElement);
  });
  
  tagSuggestions.style.display = 'block';
}

// 根据输入过滤标签建议
function filterTagSuggestions(input) {
  const tagSuggestions = document.getElementById('tagSuggestions');
  tagSuggestions.innerHTML = '';
  
  if (tagFrequencyMap.size === 0 || !input.trim()) {
    tagSuggestions.style.display = 'none';
    return;
  }
  
  const lowerInput = input.toLowerCase();
  
  // 过滤并按使用频率排序标签
  const filteredTags = Array.from(tagFrequencyMap.entries())
    .filter(([tag]) => tag.toLowerCase().includes(lowerInput))
    .sort((a, b) => b[1] - a[1]) // 按频率降序排序
    .map(entry => entry[0]);
  
  if (filteredTags.length === 0) {
    tagSuggestions.style.display = 'none';
    return;
  }
  
  // 最多显示前10个匹配的标签
  const tagsToShow = filteredTags.slice(0, 10);
  
  tagsToShow.forEach(tag => {
    const tagElement = createTagElement(tag);
    tagSuggestions.appendChild(tagElement);
  });
  
  tagSuggestions.style.display = 'block';
}

// 创建标签元素
function createTagElement(tag) {
  const tagElement = document.createElement('div');
  tagElement.className = 'tag-suggestion';
  tagElement.textContent = tag;
  
  // 显示使用频率
  const frequency = tagFrequencyMap.get(tag) || 0;
  tagElement.title = `使用次数: ${frequency}`;
  
  // 点击事件：选择标签
  tagElement.addEventListener('click', () => {
    selectTag(tag);
  });
  
  return tagElement;
}

// 获取当前正在输入的最后一个标签
function getLastTag(inputValue) {
  const tags = inputValue.split(/[,\s]/);
  return tags[tags.length - 1];
}

// 选择标签
function selectTag(tag) {
  const tagsInput = document.getElementById('tags');
  const currentValue = tagsInput.value;
  
  // 如果输入框为空，直接添加标签
  if (!currentValue.trim()) {
    tagsInput.value = tag;
    return;
  }
  
  // 替换最后一个正在输入的标签
  const tags = currentValue.split(/[,\s]/);
  tags.pop(); // 移除最后一个标签（正在输入的）
  
  // 添加选中的标签
  if (tags.length > 0) {
    tagsInput.value = tags.join(' ') + ' ' + tag;
  } else {
    tagsInput.value = tag;
  }
  
  // 隐藏建议
  document.getElementById('tagSuggestions').style.display = 'none';
  
  // 保持焦点在输入框
  tagsInput.focus();
}