let allBookmarks = [];
let currentSelectedTag = null;
let currentPage = 1;
let bookmarksPerPage = 20;
let currentBookmarks = []; // 当前显示的书签列表

// 获取设置
function getSettings() {
  return new Promise((resolve) => {
    // 在网页环境中模拟设置数据
    if (typeof chrome !== 'undefined' && chrome.storage) {
      chrome.storage.sync.get(['serverUrl', 'apiToken', 'homepageBookmarksPerPage'], (result) => {
        resolve(result);
      });
    } else {
      // 网页环境下返回模拟设置
      resolve({
        serverUrl: 'http://localhost:9090',
        apiToken: 'test-token',
        bookmarksPerPage: 20
      });
    }
  });
}

// 加载所有数据
async function loadData() {
  console.log('开始加载数据...');
  
  try {
    const settings = await getSettings();
    console.log('获取到的设置:', settings);
    
    // 设置每页显示书签数量
    bookmarksPerPage = parseInt(settings.homepageBookmarksPerPage) || 20;
    
    if (!settings.serverUrl || !settings.apiToken) {
      console.log('缺少服务器配置');
      document.getElementById('loading').style.display = 'none';
      showConfigurationNeeded();
      return;
    }
    
    console.log('开始获取书签数据...');
    
    // 获取所有书签（处理分页）
    allBookmarks = [];
    let offset = 0;
    const limit = 100; // 每次获取100个书签
    let hasMore = true;
    
    while (hasMore) {
      console.log(`获取书签，offset: ${offset}, limit: ${limit}`);
      
      const apiUrl = new URL('/api/bookmarks/', settings.serverUrl);
      apiUrl.searchParams.set('limit', limit);
      apiUrl.searchParams.set('offset', offset);
      const response = await fetch(apiUrl.href, {
        headers: {
          'Authorization': `Token ${settings.apiToken}`,
          'Content-Type': 'application/json'
        }
      });
      
      console.log('API响应状态:', response.status);
      
      if (!response.ok) {
        const errorText = await response.text();
        console.error('API请求失败:', response.status, errorText);
        throw new Error(`API请求失败: ${response.status} - ${errorText}`);
      }
      
      const data = await response.json();
      console.log('获取到的数据:', data);
      
      const bookmarks = data.results || [];
      console.log(`本次获取到 ${bookmarks.length} 个书签`);
      
      allBookmarks = allBookmarks.concat(bookmarks);
      
      // 检查是否还有更多数据
      hasMore = bookmarks.length === limit && data.next;
      offset += limit;
      
      console.log(`总书签数: ${allBookmarks.length}, 是否还有更多: ${hasMore}`);
      
      // 防止无限循环，最多获取10000个书签
      if (offset >= 10000) {
        console.log('达到最大获取限制');
        break;
      }
    }
    
    console.log('所有书签获取完成，总数:', allBookmarks.length);
    
    // 统计每个标签的书签数量
    const tagCounts = {};
    allBookmarks.forEach(bookmark => {
      if (bookmark.tag_names && Array.isArray(bookmark.tag_names)) {
        bookmark.tag_names.forEach(tagName => {
          tagCounts[tagName] = (tagCounts[tagName] || 0) + 1;
        });
      }
    });
    
    console.log('标签统计:', tagCounts);
    
    // 转换为标签对象数组
    const tags = Object.entries(tagCounts).map(([name, count]) => ({
      name,
      bookmark_count: count
    }));
    
    console.log('标签数组:', tags);
    
    renderTags(tags);
    showAllBookmarks();
    
    console.log('数据加载完成');
    
  } catch (error) {
    console.error('Error loading data:', error);
    document.getElementById('loading').style.display = 'none';
    document.getElementById('error').style.display = 'block';
    document.getElementById('error').innerHTML = `<p>加载数据时出错: ${error.message}</p><p>请检查服务器地址和API令牌是否正确</p>`;
  }
}

// 渲染标签列表
function renderTags(tags) {
  const tagsList = document.getElementById('tags-list');
  const loading = document.getElementById('loading');
  
  // 按书签数量排序，数量相同时按名称字母顺序排序
  tags.sort((a, b) => {
    if (b.bookmark_count !== a.bookmark_count) {
      return b.bookmark_count - a.bookmark_count;
    }
    return a.name.localeCompare(b.name);
  });
  
  tagsList.innerHTML = '';
  
  // 添加"所有书签"选项
  const allItem = document.createElement('li');
  allItem.className = 'tag-item active';
  allItem.innerHTML = `
    <span class="tag-name">所有书签</span>
    <span class="tag-count">${allBookmarks.length}</span>
  `;
  allItem.addEventListener('click', () => {
    selectTag(null, allItem);
    showAllBookmarks();
  });
  tagsList.appendChild(allItem);
  
  // 添加标签选项
  tags.forEach(tag => {
    const li = document.createElement('li');
    li.className = 'tag-item';
    li.innerHTML = `
      <span class="tag-name">${tag.name}</span>
      <span class="tag-count">${tag.bookmark_count}</span>
    `;
    li.addEventListener('click', () => {
      selectTag(tag.name, li);
      showBookmarksByTag(tag.name);
    });
    tagsList.appendChild(li);
  });
  
  loading.style.display = 'none';
  tagsList.style.display = 'block';
}

// 选择标签
function selectTag(tagName, element) {
  // 移除所有active类
  document.querySelectorAll('.tag-item').forEach(item => {
    item.classList.remove('active');
  });
  
  // 添加active类到当前选中的标签
  element.classList.add('active');
  
  currentSelectedTag = tagName;
  
  // 更新标题
  const currentTagElement = document.getElementById('current-tag');
  currentTagElement.textContent = tagName || '所有书签';
  
  // 显示相关标签
  showRelatedTags(tagName);
}

// 显示所有书签
function showAllBookmarks() {
  renderBookmarks(allBookmarks);
}

// 根据标签显示书签
function showBookmarksByTag(tagName) {
  const filteredBookmarks = allBookmarks.filter(bookmark => {
    return bookmark.tag_names && bookmark.tag_names.includes(tagName);
  });
  renderBookmarks(filteredBookmarks);
}

// 渲染书签列表
function renderBookmarks(bookmarks) {
  currentBookmarks = bookmarks; // 保存当前书签列表
  currentPage = 1; // 重置到第一页
  renderCurrentPage();
}

// 渲染当前页的书签
function renderCurrentPage() {
  const bookmarksList = document.getElementById('bookmarks-list');
  const emptyState = document.getElementById('empty-state');
  const paginationContainer = document.getElementById('pagination-container');
  
  if (currentBookmarks.length === 0) {
    bookmarksList.innerHTML = '';
    emptyState.style.display = 'block';
    paginationContainer.style.display = 'none';
    return;
  }
  
  emptyState.style.display = 'none';
  
  // 计算分页
  const totalPages = Math.ceil(currentBookmarks.length / bookmarksPerPage);
  const startIndex = (currentPage - 1) * bookmarksPerPage;
  const endIndex = startIndex + bookmarksPerPage;
  const currentPageBookmarks = currentBookmarks.slice(startIndex, endIndex);
  
  // 渲染书签
  bookmarksList.innerHTML = '';
  
  currentPageBookmarks.forEach(bookmark => {
    const bookmarkElement = document.createElement('div');
    bookmarkElement.className = 'bookmark-item';
    
    const tagsHtml = bookmark.tag_names && bookmark.tag_names.length > 0 
      ? bookmark.tag_names.map(tag => `<span class="bookmark-tag">${tag}</span>`).join('')
      : '';
    
    const displayUrl = bookmark.url.length > 77 ? bookmark.url.substring(0, 77) : bookmark.url;
    
    bookmarkElement.innerHTML = `
      <a href="${bookmark.url}" target="_blank" class="bookmark-title">${bookmark.title || bookmark.url}</a>
      <div class="bookmark-url">${displayUrl}</div>
      ${bookmark.description ? `<div class="bookmark-description">${bookmark.description}</div>` : ''}
      ${tagsHtml ? `<div class="bookmark-tags">${tagsHtml}</div>` : ''}
    `;
    
    bookmarksList.appendChild(bookmarkElement);
  });
  
  // 更新分页控件
  updatePagination(totalPages);
}

// 更新分页控件
function updatePagination(totalPages) {
  const paginationContainer = document.getElementById('pagination-container');
  const prevBtn = document.getElementById('prev-page');
  const nextBtn = document.getElementById('next-page');
  const currentPageSpan = document.getElementById('current-page');
  const totalPagesSpan = document.getElementById('total-pages');
  
  if (totalPages <= 1) {
    paginationContainer.style.display = 'none';
    return;
  }
  
  paginationContainer.style.display = 'flex';
  
  // 更新页码显示
  currentPageSpan.textContent = currentPage;
  totalPagesSpan.textContent = totalPages;
  
  // 更新按钮状态
  prevBtn.disabled = currentPage === 1;
  nextBtn.disabled = currentPage === totalPages;
}

// 上一页
function goToPreviousPage() {
  if (currentPage > 1) {
    currentPage--;
    renderCurrentPage();
  }
}

// 下一页
function goToNextPage() {
  const totalPages = Math.ceil(currentBookmarks.length / bookmarksPerPage);
  if (currentPage < totalPages) {
    currentPage++;
    renderCurrentPage();
  }
}

// 显示相关标签
function showRelatedTags(selectedTag) {
  const relatedTagsList = document.getElementById('related-tags-list');
  const relatedTagsEmpty = document.getElementById('related-tags-empty');
  
  if (!selectedTag) {
    // 如果没有选择标签，显示空状态
    relatedTagsList.innerHTML = '';
    relatedTagsEmpty.style.display = 'block';
    return;
  }
  
  // 找到包含选中标签的所有书签
  const bookmarksWithSelectedTag = allBookmarks.filter(bookmark => {
    return bookmark.tag_names && bookmark.tag_names.includes(selectedTag);
  });
  
  // 统计与选中标签共同出现的其他标签
  const relatedTagCounts = {};
  bookmarksWithSelectedTag.forEach(bookmark => {
    if (bookmark.tag_names && Array.isArray(bookmark.tag_names)) {
      bookmark.tag_names.forEach(tagName => {
        // 排除选中的标签本身
        if (tagName !== selectedTag) {
          relatedTagCounts[tagName] = (relatedTagCounts[tagName] || 0) + 1;
        }
      });
    }
  });
  
  // 转换为数组并排序，数量相同时按名称字母顺序排序
  const relatedTags = Object.entries(relatedTagCounts)
    .map(([name, count]) => ({ name, count }))
    .sort((a, b) => {
      if (b.count !== a.count) {
        return b.count - a.count;
      }
      return a.name.localeCompare(b.name);
    });
  
  if (relatedTags.length === 0) {
    relatedTagsList.innerHTML = '';
    relatedTagsEmpty.style.display = 'block';
    relatedTagsEmpty.textContent = '暂无相关标签';
    return;
  }
  
  // 渲染相关标签
  relatedTagsEmpty.style.display = 'none';
  relatedTagsList.innerHTML = '';
  
  relatedTags.forEach(tag => {
    const li = document.createElement('li');
    li.className = 'related-tag-item';
    li.innerHTML = `
      <span class="related-tag-name">${tag.name}</span>
      <span class="related-tag-count">${tag.count}</span>
    `;
    
    // 点击相关标签时切换到该标签
    li.addEventListener('click', () => {
      // 找到左侧对应的标签元素并触发点击
      const tagItems = document.querySelectorAll('.tag-item');
      tagItems.forEach(item => {
        const tagNameElement = item.querySelector('.tag-name');
        if (tagNameElement && tagNameElement.textContent === tag.name) {
          item.click();
        }
      });
    });
    
    relatedTagsList.appendChild(li);
  });
}

// 同时滚动功能
function setupSyncScroll() {
  const bookmarksContainer = document.querySelector('.bookmarks-container');
  const relatedTagsList = document.querySelector('.related-tags-list');
  
  // 检查元素是否存在
  if (!bookmarksContainer || !relatedTagsList) {
    console.log('滚动元素未找到:', {
      bookmarksContainer: !!bookmarksContainer,
      relatedTagsList: !!relatedTagsList
    });
    return;
  }
  
  let isScrolling = false;
  
  // 书签容器滚动时同步相关标签列表
  bookmarksContainer.addEventListener('scroll', () => {
    if (isScrolling) return;
    isScrolling = true;
    
    // 计算滚动比例
    const scrollPercentage = bookmarksContainer.scrollTop / Math.max(1, bookmarksContainer.scrollHeight - bookmarksContainer.clientHeight);
    const targetScrollTop = scrollPercentage * Math.max(0, relatedTagsList.scrollHeight - relatedTagsList.clientHeight);
    
    relatedTagsList.scrollTop = targetScrollTop;
    
    setTimeout(() => {
      isScrolling = false;
    }, 10);
  });
  
  // 相关标签列表滚动时同步书签容器
  relatedTagsList.addEventListener('scroll', () => {
    if (isScrolling) return;
    isScrolling = true;
    
    // 计算滚动比例
    const scrollPercentage = relatedTagsList.scrollTop / Math.max(1, relatedTagsList.scrollHeight - relatedTagsList.clientHeight);
    const targetScrollTop = scrollPercentage * Math.max(0, bookmarksContainer.scrollHeight - bookmarksContainer.clientHeight);
    
    bookmarksContainer.scrollTop = targetScrollTop;
    
    setTimeout(() => {
      isScrolling = false;
    }, 10);
  });
  
  // 为两个容器添加滚轮事件，实现同时滚动
  function handleWheel(e) {
    e.preventDefault();
    
    const scrollAmount = e.deltaY * 0.5; // 减慢滚动速度
    
    // 同时滚动两个区域
    const newBookmarksScroll = Math.max(0, Math.min(
      bookmarksContainer.scrollHeight - bookmarksContainer.clientHeight,
      bookmarksContainer.scrollTop + scrollAmount
    ));
    
    const newRelatedScroll = Math.max(0, Math.min(
      relatedTagsList.scrollHeight - relatedTagsList.clientHeight,
      relatedTagsList.scrollTop + scrollAmount
    ));
    
    isScrolling = true;
    bookmarksContainer.scrollTop = newBookmarksScroll;
    relatedTagsList.scrollTop = newRelatedScroll;
    
    setTimeout(() => {
      isScrolling = false;
    }, 10);
  }
  
  bookmarksContainer.addEventListener('wheel', handleWheel, { passive: false });
  relatedTagsList.addEventListener('wheel', handleWheel, { passive: false });
  
  console.log('同时滚动功能已设置');
}

// 显示配置需要提示
function showConfigurationNeeded() {
  document.getElementById('error').innerHTML = `
    <div style="text-align: center; padding: 40px;">
      <div style="font-size: 24px; margin-bottom: 20px;">⚙️</div>
      <div style="font-size: 18px; margin-bottom: 15px; color: #333;">需要配置</div>
      <div style="margin-bottom: 20px; color: #666;">请先配置服务器URL和API令牌</div>
      <button onclick="openSettings()" style="
        padding: 12px 24px;
        background: linear-gradient(135deg, #007bff, #0056b3);
        color: white;
        border: none;
        border-radius: 6px;
        cursor: pointer;
        font-size: 14px;
        font-weight: 500;
        transition: all 0.3s ease;
      " onmouseover="this.style.transform='translateY(-1px)'; this.style.boxShadow='0 4px 12px rgba(0,123,255,0.3)'" onmouseout="this.style.transform='translateY(0)'; this.style.boxShadow='none'">前往设置</button>
    </div>
  `;
  document.getElementById('error').style.display = 'block';
  
  // 同时在书签区域显示提示
  document.getElementById('bookmarks-list').innerHTML = `
    <div style="text-align: center; padding: 60px 20px; color: #666;">
      <div style="font-size: 48px; margin-bottom: 20px; opacity: 0.3;">📚</div>
      <div style="font-size: 16px; margin-bottom: 10px; color: #333;">暂无数据</div>
      <div style="opacity: 0.8;">配置完成后即可显示您的书签</div>
    </div>
  `;
}

// 打开设置页面
function openSettings() {
  chrome.tabs.create({ url: chrome.runtime.getURL('options.html') });
}

// 搜索功能
let searchTimeout;
function setupSearch() {
  const searchInput = document.getElementById('search-input');
  const searchButton = document.getElementById('search-button');
  
  if (!searchInput || !searchButton) return;
  
  // 搜索输入事件
  searchInput.addEventListener('input', (e) => {
    clearTimeout(searchTimeout);
    searchTimeout = setTimeout(() => {
      performSearch(e.target.value.trim());
    }, 300); // 防抖，300ms后执行搜索
  });
  
  // 搜索按钮点击事件
  searchButton.addEventListener('click', () => {
    performSearch(searchInput.value.trim());
  });
  
  // 回车键搜索
  searchInput.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') {
      performSearch(e.target.value.trim());
    }
  });
}

// 执行搜索
function performSearch(query) {
  console.log('执行搜索:', query);
  
  if (!query) {
    // 如果搜索为空，显示当前选中标签的书签
    if (currentSelectedTag) {
      showBookmarksByTag(currentSelectedTag);
    } else {
      showAllBookmarks();
    }
    return;
  }
  
  // 过滤书签
  const filteredBookmarks = allBookmarks.filter(bookmark => {
    const titleMatch = bookmark.title.toLowerCase().includes(query.toLowerCase());
    const urlMatch = bookmark.url.toLowerCase().includes(query.toLowerCase());
    const descriptionMatch = bookmark.description && bookmark.description.toLowerCase().includes(query.toLowerCase());
    const tagsMatch = bookmark.tag_names && bookmark.tag_names.some(tag => 
      tag.toLowerCase().includes(query.toLowerCase())
    );
    
    return titleMatch || urlMatch || descriptionMatch || tagsMatch;
  });
  
  console.log(`搜索结果: ${filteredBookmarks.length} 个书签`);
  
  // 显示搜索结果
  renderBookmarks(filteredBookmarks);
  
  // 更新当前标签显示
  const currentTagElement = document.getElementById('current-tag');
  if (currentTagElement) {
    currentTagElement.textContent = `搜索结果: "${query}" (${filteredBookmarks.length})`;
  }
  
  // 清空相关标签
  const relatedTagsList = document.getElementById('related-tags-list');
  const relatedTagsEmpty = document.getElementById('related-tags-empty');
  if (relatedTagsList && relatedTagsEmpty) {
    relatedTagsList.innerHTML = '';
    relatedTagsEmpty.style.display = 'block';
    relatedTagsEmpty.textContent = '搜索模式下不显示相关标签';
  }
}

// 页面加载时执行
document.addEventListener('DOMContentLoaded', async () => {
  await loadData(); // Ensure data is loaded before trying to access settings
  setupSyncScroll();
  setupSearch();
  setupPagination();

  // Setup open configured URL link
  const openConfiguredUrlLink = document.getElementById('open-configured-url-link');
  if (openConfiguredUrlLink) {
    try {
      const settings = await getSettings();
      if (settings.serverUrl) {
        openConfiguredUrlLink.href = settings.serverUrl;
        openConfiguredUrlLink.textContent = `打开主页 (${new URL(settings.serverUrl).hostname})`;
        openConfiguredUrlLink.target = '_blank'; // Open in new tab
        openConfiguredUrlLink.style.display = 'inline-flex'; // Show the link
      }
    } catch (error) {
      console.error('Error setting up configured URL link:', error);
    }
  }
});

// 设置分页事件监听器
function setupPagination() {
  const prevBtn = document.getElementById('prev-page');
  const nextBtn = document.getElementById('next-page');
  
  if (prevBtn) {
    prevBtn.addEventListener('click', goToPreviousPage);
  }
  
  if (nextBtn) {
    nextBtn.addEventListener('click', goToNextPage);
  }
}