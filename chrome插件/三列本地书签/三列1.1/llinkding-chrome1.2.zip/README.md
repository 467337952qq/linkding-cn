# 雷柠2.0横向插件 Chrome插件

雷柠2.0横向插件是一个Chrome浏览器插件，用于连接到[linkding](https://github.com/sissbruecker/linkding)书签管理系统的API，并显示您的个人书签。

## 功能

- 连接到您的linkding服务器
- 查看您的书签列表
- 搜索书签
- 按未读和已归档状态筛选书签
- 点击书签在新标签页中打开

## 安装说明

### 从Chrome网上应用店安装

*即将上线*

### 手动安装

1. 下载此仓库的ZIP文件并解压
2. 打开Chrome浏览器，进入扩展程序页面 (chrome://extensions/)
3. 开启右上角的「开发者模式」
4. 点击「加载已解压的扩展程序」
5. 选择解压后的文件夹

## 使用方法

1. 安装插件后，会自动打开设置页面
2. 输入您的linkding服务器URL（例如：https://linkding.example.com）
3. 输入您的API令牌（可以在linkding设置页面找到）
4. 点击「保存设置」
5. 点击Chrome工具栏中的插件图标，即可查看您的书签

## 隐私说明

- 此插件仅连接到您指定的linkding服务器
- 您的API令牌和服务器URL仅存储在浏览器本地，不会发送到其他地方
- 插件不收集任何使用数据

## 许可证

[MIT](LICENSE)