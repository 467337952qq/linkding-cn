document.addEventListener('DOMContentLoaded', function() {
  // 加载保存的设置
  chrome.storage.sync.get(['serverUrl', 'apiToken'], function(items) {
    if (items.serverUrl) {
      document.getElementById('serverUrl').value = items.serverUrl;
    }
    if (items.apiToken) {
      document.getElementById('apiToken').value = items.apiToken;
    }
  });

  // 保存设置按钮点击事件
  document.getElementById('saveBtn').addEventListener('click', function() {
    const serverUrl = document.getElementById('serverUrl').value.trim();
    const apiToken = document.getElementById('apiToken').value.trim();
    const statusMessage = document.getElementById('statusMessage');
    
    // 验证输入
    if (!serverUrl || !apiToken) {
      showStatus('请填写所有必填字段', 'error');
      return;
    }

    // 验证服务器URL格式
    try {
      new URL(serverUrl);
    } catch (e) {
      showStatus('请输入有效的URL', 'error');
      return;
    }

    // 测试API连接
    testConnection(serverUrl, apiToken)
      .then(success => {
        if (success) {
          // 保存设置
          chrome.storage.sync.set({
            serverUrl: serverUrl,
            apiToken: apiToken
          }, function() {
            showStatus('设置已保存', 'success');
          });
        } else {
          showStatus('无法连接到服务器，请检查URL和API令牌', 'error');
        }
      })
      .catch(error => {
        showStatus('连接错误: ' + error.message, 'error');
      });
  });

  // 打开主页按钮点击事件
  document.getElementById('openHomepageBtn').addEventListener('click', function() {
    // 检查是否已配置设置
    chrome.storage.sync.get(['serverUrl', 'apiToken'], function(items) {
      if (items.serverUrl && items.apiToken) {
        // 打开主页
        chrome.tabs.create({ url: 'homepage.html' });
      } else {
        showStatus('请先保存有效的服务器设置', 'error');
      }
    });
  });

  // 测试API连接
  function testConnection(serverUrl, apiToken) {
    const url = new URL('/api/bookmarks/', serverUrl).href;
    return fetch(url, {
      method: 'GET',
      headers: {
        'Authorization': 'Token ' + apiToken
      }
    })
    .then(response => {
      return response.ok;
    })
    .catch(error => {
      console.error('连接测试失败:', error);
      return false;
    });
  }

  // 显示状态消息
  function showStatus(message, type) {
    const statusMessage = document.getElementById('statusMessage');
    statusMessage.textContent = message;
    statusMessage.className = 'status ' + type;
    statusMessage.classList.remove('hidden');
    
    // 3秒后隐藏消息
    setTimeout(function() {
      statusMessage.classList.add('hidden');
    }, 3000);
  }
});