// 全局变量
let allBookmarks = [];
let currentSelectedTag = null;

// 获取设置
function getSettings() {
  return new Promise((resolve) => {
    chrome.storage.sync.get(['serverUrl', 'apiToken'], (result) => {
      resolve(result);
    });
  });
}

// 加载所有数据
async function loadData() {
  try {
    const settings = await getSettings();
    
    if (!settings.serverUrl || !settings.apiToken) {
      document.getElementById('loading').style.display = 'none';
      document.getElementById('error').style.display = 'block';
      return;
    }
    
    // 获取所有书签（处理分页）
    allBookmarks = [];
    let offset = 0;
    const limit = 100; // 每次获取100个书签
    let hasMore = true;
    
    while (hasMore) {
      const response = await fetch(`${settings.serverUrl}/api/bookmarks/?limit=${limit}&offset=${offset}`, {
        headers: {
          'Authorization': `Token ${settings.apiToken}`
        }
      });
      
      if (!response.ok) {
        throw new Error('Failed to fetch bookmarks');
      }
      
      const data = await response.json();
      const bookmarks = data.results || [];
      
      allBookmarks = allBookmarks.concat(bookmarks);
      
      // 检查是否还有更多数据
      hasMore = bookmarks.length === limit && data.next;
      offset += limit;
      
      // 防止无限循环，最多获取10000个书签
      if (offset >= 10000) {
        break;
      }
    }
    
    // 统计每个标签的书签数量
    const tagCounts = {};
    allBookmarks.forEach(bookmark => {
      if (bookmark.tag_names && Array.isArray(bookmark.tag_names)) {
        bookmark.tag_names.forEach(tagName => {
          tagCounts[tagName] = (tagCounts[tagName] || 0) + 1;
        });
      }
    });
    
    // 转换为标签对象数组
    const tags = Object.entries(tagCounts).map(([name, count]) => ({
      name,
      bookmark_count: count
    }));
    
    renderTags(tags);
    showAllBookmarks();
    
  } catch (error) {
    console.error('Error loading data:', error);
    document.getElementById('loading').style.display = 'none';
    document.getElementById('error').style.display = 'block';
  }
}

// 渲染标签列表
function renderTags(tags) {
  const tagsList = document.getElementById('tags-list');
  const loading = document.getElementById('loading');
  
  // 按书签数量排序，数量相同时按名称字母顺序排序
  tags.sort((a, b) => {
    if (b.bookmark_count !== a.bookmark_count) {
      return b.bookmark_count - a.bookmark_count;
    }
    return a.name.localeCompare(b.name);
  });
  
  tagsList.innerHTML = '';
  
  // 添加"所有书签"选项
  const allItem = document.createElement('li');
  allItem.className = 'tag-item active';
  allItem.innerHTML = `
    <span class="tag-name">所有书签</span>
    <span class="tag-count">${allBookmarks.length}</span>
  `;
  allItem.addEventListener('click', () => {
    selectTag(null, allItem);
    showAllBookmarks();
  });
  tagsList.appendChild(allItem);
  
  // 添加标签选项
  tags.forEach(tag => {
    const li = document.createElement('li');
    li.className = 'tag-item';
    li.innerHTML = `
      <span class="tag-name">${tag.name}</span>
      <span class="tag-count">${tag.bookmark_count}</span>
    `;
    li.addEventListener('click', () => {
      selectTag(tag.name, li);
      showBookmarksByTag(tag.name);
    });
    tagsList.appendChild(li);
  });
  
  loading.style.display = 'none';
  tagsList.style.display = 'block';
}

// 选择标签
function selectTag(tagName, element) {
  // 移除所有active类
  document.querySelectorAll('.tag-item').forEach(item => {
    item.classList.remove('active');
  });
  
  // 添加active类到当前选中的标签
  element.classList.add('active');
  
  currentSelectedTag = tagName;
  
  // 更新标题
  const currentTagElement = document.getElementById('current-tag');
  currentTagElement.textContent = tagName || '所有书签';
  
  // 显示相关标签
  showRelatedTags(tagName);
}

// 显示所有书签
function showAllBookmarks() {
  renderBookmarks(allBookmarks);
}

// 根据标签显示书签
function showBookmarksByTag(tagName) {
  const filteredBookmarks = allBookmarks.filter(bookmark => {
    return bookmark.tag_names && bookmark.tag_names.includes(tagName);
  });
  renderBookmarks(filteredBookmarks);
}

// 渲染书签列表
function renderBookmarks(bookmarks) {
  const bookmarksList = document.getElementById('bookmarks-list');
  const emptyState = document.getElementById('empty-state');
  
  if (bookmarks.length === 0) {
    bookmarksList.innerHTML = '';
    emptyState.style.display = 'block';
    return;
  }
  
  emptyState.style.display = 'none';
  
  bookmarksList.innerHTML = '';
  
  bookmarks.forEach(bookmark => {
    const bookmarkElement = document.createElement('div');
    bookmarkElement.className = 'bookmark-item';
    
    const tagsHtml = bookmark.tag_names && bookmark.tag_names.length > 0 
      ? bookmark.tag_names.map(tag => `<span class="bookmark-tag">${tag}</span>`).join('')
      : '';
    
    bookmarkElement.innerHTML = `
      <a href="${bookmark.url}" target="_blank" class="bookmark-title">${bookmark.title || bookmark.url}</a>
      <div class="bookmark-url">${bookmark.url}</div>
      ${bookmark.description ? `<div class="bookmark-description">${bookmark.description}</div>` : ''}
      ${tagsHtml ? `<div class="bookmark-tags">${tagsHtml}</div>` : ''}
    `;
    
    bookmarksList.appendChild(bookmarkElement);
  });
}

// 显示相关标签
function showRelatedTags(selectedTag) {
  const relatedTagsList = document.getElementById('related-tags-list');
  const relatedTagsEmpty = document.getElementById('related-tags-empty');
  
  if (!selectedTag) {
    // 如果没有选择标签，显示空状态
    relatedTagsList.innerHTML = '';
    relatedTagsEmpty.style.display = 'block';
    return;
  }
  
  // 找到包含选中标签的所有书签
  const bookmarksWithSelectedTag = allBookmarks.filter(bookmark => {
    return bookmark.tag_names && bookmark.tag_names.includes(selectedTag);
  });
  
  // 统计与选中标签共同出现的其他标签
  const relatedTagCounts = {};
  bookmarksWithSelectedTag.forEach(bookmark => {
    if (bookmark.tag_names && Array.isArray(bookmark.tag_names)) {
      bookmark.tag_names.forEach(tagName => {
        // 排除选中的标签本身
        if (tagName !== selectedTag) {
          relatedTagCounts[tagName] = (relatedTagCounts[tagName] || 0) + 1;
        }
      });
    }
  });
  
  // 转换为数组并排序，数量相同时按名称字母顺序排序
  const relatedTags = Object.entries(relatedTagCounts)
    .map(([name, count]) => ({ name, count }))
    .sort((a, b) => {
      if (b.count !== a.count) {
        return b.count - a.count;
      }
      return a.name.localeCompare(b.name);
    });
  
  if (relatedTags.length === 0) {
    relatedTagsList.innerHTML = '';
    relatedTagsEmpty.style.display = 'block';
    relatedTagsEmpty.textContent = '暂无相关标签';
    return;
  }
  
  // 渲染相关标签
  relatedTagsEmpty.style.display = 'none';
  relatedTagsList.innerHTML = '';
  
  relatedTags.forEach(tag => {
    const li = document.createElement('li');
    li.className = 'related-tag-item';
    li.innerHTML = `
      <span class="related-tag-name">${tag.name}</span>
      <span class="related-tag-count">${tag.count}</span>
    `;
    
    // 点击相关标签时切换到该标签
    li.addEventListener('click', () => {
      // 找到左侧对应的标签元素并触发点击
      const tagItems = document.querySelectorAll('.tag-item');
      tagItems.forEach(item => {
        const tagNameElement = item.querySelector('.tag-name');
        if (tagNameElement && tagNameElement.textContent === tag.name) {
          item.click();
        }
      });
    });
    
    relatedTagsList.appendChild(li);
  });
}

// 同时滚动功能
function setupSyncScroll() {
  const bookmarksContainer = document.querySelector('.bookmarks-container');
  const relatedTagsList = document.querySelector('.related-tags-list');
  
  // 检查元素是否存在
  if (!bookmarksContainer || !relatedTagsList) {
    console.log('滚动元素未找到:', {
      bookmarksContainer: !!bookmarksContainer,
      relatedTagsList: !!relatedTagsList
    });
    return;
  }
  
  let isScrolling = false;
  
  // 书签容器滚动时同步相关标签列表
  bookmarksContainer.addEventListener('scroll', () => {
    if (isScrolling) return;
    isScrolling = true;
    
    // 计算滚动比例
    const scrollPercentage = bookmarksContainer.scrollTop / Math.max(1, bookmarksContainer.scrollHeight - bookmarksContainer.clientHeight);
    const targetScrollTop = scrollPercentage * Math.max(0, relatedTagsList.scrollHeight - relatedTagsList.clientHeight);
    
    relatedTagsList.scrollTop = targetScrollTop;
    
    setTimeout(() => {
      isScrolling = false;
    }, 10);
  });
  
  // 相关标签列表滚动时同步书签容器
  relatedTagsList.addEventListener('scroll', () => {
    if (isScrolling) return;
    isScrolling = true;
    
    // 计算滚动比例
    const scrollPercentage = relatedTagsList.scrollTop / Math.max(1, relatedTagsList.scrollHeight - relatedTagsList.clientHeight);
    const targetScrollTop = scrollPercentage * Math.max(0, bookmarksContainer.scrollHeight - bookmarksContainer.clientHeight);
    
    bookmarksContainer.scrollTop = targetScrollTop;
    
    setTimeout(() => {
      isScrolling = false;
    }, 10);
  });
  
  // 为两个容器添加滚轮事件，实现同时滚动
  function handleWheel(e) {
    e.preventDefault();
    
    const scrollAmount = e.deltaY * 0.5; // 减慢滚动速度
    
    // 同时滚动两个区域
    const newBookmarksScroll = Math.max(0, Math.min(
      bookmarksContainer.scrollHeight - bookmarksContainer.clientHeight,
      bookmarksContainer.scrollTop + scrollAmount
    ));
    
    const newRelatedScroll = Math.max(0, Math.min(
      relatedTagsList.scrollHeight - relatedTagsList.clientHeight,
      relatedTagsList.scrollTop + scrollAmount
    ));
    
    isScrolling = true;
    bookmarksContainer.scrollTop = newBookmarksScroll;
    relatedTagsList.scrollTop = newRelatedScroll;
    
    setTimeout(() => {
      isScrolling = false;
    }, 10);
  }
  
  bookmarksContainer.addEventListener('wheel', handleWheel, { passive: false });
  relatedTagsList.addEventListener('wheel', handleWheel, { passive: false });
  
  console.log('同时滚动功能已设置');
}

// 页面加载时执行
document.addEventListener('DOMContentLoaded', () => {
  loadData();
  setupSyncScroll();
});