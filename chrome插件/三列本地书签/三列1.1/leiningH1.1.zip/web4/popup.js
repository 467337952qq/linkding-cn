document.addEventListener('DOMContentLoaded', function() {
  // 状态变量
  let currentOffset = 0;
  let currentLimit = 20;
  let hasMoreBookmarks = true;
  let currentFilter = 'all';
  let currentSearchQuery = '';
  let isLoading = false;
  
  // DOM元素
  const bookmarksContainer = document.getElementById('bookmarksContainer');
  const loadMoreBtn = document.getElementById('loadMoreBtn');
  const searchInput = document.getElementById('searchInput');
  const settingsBtn = document.getElementById('settingsBtn');
  const addBookmarkBtn = document.getElementById('addBookmarkBtn');
  const filterButtons = document.querySelectorAll('.filter-btn');
  
  // 初始化
  init();
  
  // 初始化函数
  function init() {
    // 检查设置
    checkSettings()
      .then(hasSettings => {
        if (hasSettings) {
          // 加载书签
          loadBookmarks();
          
          // 设置事件监听器
          setupEventListeners();
          
          // 显示服务器URL
          loadServerUrlDisplay();
        } else {
          showNoSettingsMessage();
        }
      });
  }
  
  // 检查是否已配置设置
  function checkSettings() {
    return new Promise(resolve => {
      chrome.storage.sync.get(['serverUrl', 'apiToken'], function(items) {
        resolve(items.serverUrl && items.apiToken);
      });
    });
  }
  
  // 设置事件监听器
  function setupEventListeners() {
    // 设置按钮点击事件
    settingsBtn.addEventListener('click', function() {
      chrome.runtime.openOptionsPage();
    });
    
    // 添加书签按钮点击事件
    addBookmarkBtn.addEventListener('click', function() {
      // 获取当前标签页
      chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
        if (tabs && tabs.length > 0) {
          // 创建一个新的窗口来添加书签
          chrome.windows.create({
            url: chrome.runtime.getURL('add-bookmark.html'),
            type: 'popup',
            width: 400,
            height: 500
          });
          // 关闭当前弹出窗口
          window.close();
        }
      });
    });
    
    // 搜索输入事件
    searchInput.addEventListener('input', debounce(function() {
      currentSearchQuery = searchInput.value.trim();
      resetBookmarksList();
      loadBookmarks();
    }, 300));
    
    // 加载更多按钮点击事件
    loadMoreBtn.addEventListener('click', function() {
      if (!isLoading && hasMoreBookmarks) {
        loadBookmarks(false);
      }
    });
    
    // 过滤按钮点击事件
    filterButtons.forEach(button => {
      button.addEventListener('click', function() {
        // 更新活动按钮
        filterButtons.forEach(btn => btn.classList.remove('active'));
        this.classList.add('active');
        
        // 设置当前过滤器
        currentFilter = this.dataset.filter;
        
        // 重置并重新加载书签
        resetBookmarksList();
        loadBookmarks();
      });
    });
  }
  
  // 重置书签列表状态
  function resetBookmarksList() {
    bookmarksContainer.innerHTML = '';
    currentOffset = 0;
    hasMoreBookmarks = true;
    loadMoreBtn.style.display = 'none';
  }
  
  // 加载书签
  function loadBookmarks(showLoading = true) {
    if (isLoading) return;
    isLoading = true;
    
    if (showLoading) {
      showLoadingIndicator();
    }
    
    // 获取设置
    chrome.storage.sync.get(['serverUrl', 'apiToken'], function(items) {
      const { serverUrl, apiToken } = items;
      
      // 构建API URL
      let apiUrl = new URL('/api/bookmarks/', serverUrl).href;
      
      // 添加查询参数
      const params = new URLSearchParams();
      params.append('limit', currentLimit.toString());
      params.append('offset', currentOffset.toString());
      
      // 添加搜索查询
      if (currentSearchQuery) {
        params.append('q', currentSearchQuery);
      }
      
      // 根据过滤器调整URL
      if (currentFilter === 'archived') {
        apiUrl = new URL('/api/bookmarks/archived/', serverUrl).href;
      } else if (currentFilter === 'unread') {
        params.append('q', 'unread:true' + (currentSearchQuery ? ' ' + currentSearchQuery : ''));
      }
      
      apiUrl += '?' + params.toString();
      
      // 发送API请求
      fetch(apiUrl, {
        method: 'GET',
        headers: {
          'Authorization': 'Token ' + apiToken
        }
      })
      .then(response => {
        if (!response.ok) {
          if (response.status === 404) {
            throw new Error('服务器地址不正确或API端点不存在 (404)');
          } else if (response.status === 401) {
            throw new Error('API令牌无效或已过期 (401)');
          } else if (response.status === 403) {
            throw new Error('没有访问权限 (403)');
          } else if (response.status >= 500) {
            throw new Error('服务器内部错误 (' + response.status + ')');
          } else {
            throw new Error('API请求失败: ' + response.status);
          }
        }
        return response.json();
      })
      .then(data => {
        // 移除加载指示器
        removeLoadingIndicator();
        
        // 处理结果
        if (data.results && data.results.length > 0) {
          // 渲染书签
          renderBookmarks(data.results);
          
          // 更新分页状态
          currentOffset += data.results.length;
          hasMoreBookmarks = data.next !== null;
          
          // 显示/隐藏加载更多按钮
          loadMoreBtn.style.display = hasMoreBookmarks ? 'block' : 'none';
        } else if (currentOffset === 0) {
          // 没有结果
          showNoResultsMessage();
        }
        
        isLoading = false;
      })
      .catch(error => {
        console.error('获取书签失败:', error);
        removeLoadingIndicator();
        showErrorMessage(error.message);
        isLoading = false;
      });
    });
  }
  
  // 渲染书签
  function renderBookmarks(bookmarks) {
    bookmarks.forEach(bookmark => {
      const bookmarkElement = document.createElement('div');
      bookmarkElement.className = 'bookmark-item';
      bookmarkElement.dataset.id = bookmark.id;
      bookmarkElement.dataset.url = bookmark.url;
      
      // 创建书签标题
      const titleElement = document.createElement('div');
      titleElement.className = 'bookmark-title';
      titleElement.textContent = bookmark.title || '无标题';
      
      // 创建书签URL
      const urlElement = document.createElement('div');
      urlElement.className = 'bookmark-url';
      urlElement.textContent = bookmark.url;
      
      // 添加标签（如果有）
      let tagsElement = '';
      if (bookmark.tag_names && bookmark.tag_names.length > 0) {
        tagsElement = document.createElement('div');
        tagsElement.className = 'bookmark-tags';
        
        bookmark.tag_names.forEach(tag => {
          const tagElement = document.createElement('span');
          tagElement.className = 'tag';
          tagElement.textContent = tag;
          tagsElement.appendChild(tagElement);
        });
      }
      
      // 组装书签元素
      bookmarkElement.appendChild(titleElement);
      bookmarkElement.appendChild(urlElement);
      if (tagsElement) {
        bookmarkElement.appendChild(tagsElement);
      }
      
      // 添加点击事件
      bookmarkElement.addEventListener('click', function() {
        chrome.tabs.create({ url: bookmark.url });
      });
      
      // 添加到容器
      bookmarksContainer.appendChild(bookmarkElement);
    });
  }
  
  // 显示加载指示器
  function showLoadingIndicator() {
    if (currentOffset === 0) {
      bookmarksContainer.innerHTML = '<div class="loading">加载中...</div>';
    }
  }
  
  // 移除加载指示器
  function removeLoadingIndicator() {
    const loadingElement = bookmarksContainer.querySelector('.loading');
    if (loadingElement) {
      loadingElement.remove();
    }
  }
  
  // 显示错误消息
  function showErrorMessage(message) {
    // 移除现有的错误提示
    const existingError = document.querySelector('.error');
    if (existingError) {
      existingError.remove();
    }
    
    const errorDiv = document.createElement('div');
    errorDiv.className = 'error';
    errorDiv.style.cssText = `
      position: fixed;
      top: 20px;
      left: 50%;
      transform: translateX(-50%);
      z-index: 9999;
      max-width: 400px;
      white-space: pre-line;
      box-shadow: 0 4px 12px rgba(0,0,0,0.15);
    `;
    errorDiv.textContent = '错误: ' + message;
    document.body.appendChild(errorDiv);
    
    setTimeout(() => {
      if (errorDiv.parentNode) {
        errorDiv.remove();
      }
    }, 8000);
  }
  
  // 显示无结果消息
  function showNoResultsMessage() {
    bookmarksContainer.innerHTML = '<div class="loading">没有找到书签</div>';
  }
  
  // 显示未配置设置消息
  function showNoSettingsMessage() {
    bookmarksContainer.innerHTML = `
      <div class="no-settings">
        <p>请先配置服务器设置</p>
        <button id="goToSettingsBtn">前往设置</button>
      </div>
    `;
    
    document.getElementById('goToSettingsBtn').addEventListener('click', function() {
      chrome.runtime.openOptionsPage();
    });
  }
  
  // 防抖函数
  function debounce(func, wait) {
    let timeout;
    return function() {
      const context = this;
      const args = arguments;
      clearTimeout(timeout);
      timeout = setTimeout(function() {
        func.apply(context, args);
      }, wait);
    };
  }
  
  // 加载服务器URL显示
  function loadServerUrlDisplay() {
    chrome.storage.sync.get(['serverUrl'], function(items) {
      updateServerUrlDisplay(items.serverUrl);
    });
  }
  
  // 更新服务器URL显示
  function updateServerUrlDisplay(serverUrl) {
    const serverUrlDisplay = document.getElementById('serverUrlDisplay');
    
    if (serverUrl && serverUrlDisplay) {
      try {
        const url = new URL(serverUrl);
        const hostname = url.hostname;
        serverUrlDisplay.textContent = `主页${hostname}`;
        serverUrlDisplay.style.display = 'inline';
        
        // 添加点击事件
        serverUrlDisplay.onclick = function() {
          chrome.tabs.create({ url: serverUrl });
        };
        
        // 检测连接状态
        checkServerConnection(serverUrl, hostname);
      } catch (e) {
        serverUrlDisplay.style.display = 'none';
      }
    } else if (serverUrlDisplay) {
      serverUrlDisplay.style.display = 'none';
    }
  }
  
  // 检测服务器连接状态
  function checkServerConnection(serverUrl, hostname) {
    const serverUrlDisplay = document.getElementById('serverUrlDisplay');
    if (!serverUrlDisplay) return;
    
    chrome.storage.sync.get(['apiToken'], function(items) {
      if (!items.apiToken) {
        serverUrlDisplay.textContent = `主页${hostname} (未配置令牌)`;
        serverUrlDisplay.style.color = '#ff6b6b';
        return;
      }
      
      // 测试API连接
      const apiUrl = serverUrl.replace(/\/$/, '') + '/api/bookmarks/?limit=1';
      fetch(apiUrl, {
        method: 'GET',
        headers: {
          'Authorization': 'Token ' + items.apiToken
        }
      })
      .then(response => {
        if (response.ok) {
          serverUrlDisplay.textContent = `主页${hostname} (已连接)`;
          serverUrlDisplay.style.color = '#007bff';
        } else {
          serverUrlDisplay.textContent = `主页${hostname} (连接失败)`;
          serverUrlDisplay.style.color = '#ff6b6b';
        }
      })
      .catch(error => {
        serverUrlDisplay.textContent = `主页${hostname} (无法连接)`;
        serverUrlDisplay.style.color = '#ff6b6b';
      });
    });
  }
});