document.addEventListener('DOMContentLoaded', function() {
  // 获取DOM元素
  const optionsForm = document.getElementById('optionsForm');
  const baseUrlInput = document.getElementById('baseUrl');
  const apiTokenInput = document.getElementById('apiToken');
  const defaultTagsInput = document.getElementById('defaultTags');
  const bookmarksPerPageInput = document.getElementById('bookmarksPerPage');
  const maxTagsDisplayInput = document.getElementById('maxTagsDisplay');
  const defaultUnreadInput = document.getElementById('defaultUnread');
  const defaultSharedInput = document.getElementById('defaultShared');
  const enableBookmarkComparisonInput = document.getElementById('enableBookmarkComparison');
  const openMainBtn = document.getElementById('openMainBtn');
  
  // 加载已保存的设置
  loadSettings();
  
  // 表单提交事件
  optionsForm.addEventListener('submit', function(e) {
    e.preventDefault();
    saveSettings();
  });
  
  // 打开主页按钮点击事件
  openMainBtn.addEventListener('click', function() {
    const serverUrl = baseUrlInput.value.trim();
    if (serverUrl) {
      chrome.tabs.create({ url: serverUrl });
    } else {
      showStatus('请先设置服务器URL', 'error');
    }
  });
  
  // 加载设置
  function loadSettings() {
    chrome.storage.sync.get([
      'serverUrl', 'apiToken', 'defaultTags', 'bookmarksPerPage', 'maxTagsDisplay',
      'defaultUnread', 'defaultShared', 'enableBookmarkComparison'
    ], function(items) {
      if (items.serverUrl) {
        baseUrlInput.value = items.serverUrl;
      }
      if (items.apiToken) {
        apiTokenInput.value = items.apiToken;
      }
      if (items.defaultTags) {
        defaultTagsInput.value = items.defaultTags;
      }
      if (items.bookmarksPerPage) {
        bookmarksPerPageInput.value = items.bookmarksPerPage;
      }
      if (items.maxTagsDisplay) {
        maxTagsDisplayInput.value = items.maxTagsDisplay;
      }
      defaultUnreadInput.checked = items.defaultUnread || false;
      defaultSharedInput.checked = items.defaultShared || false;
      enableBookmarkComparisonInput.checked = items.enableBookmarkComparison || false;
    });
  }
  
  // 保存设置
  function saveSettings() {
    const serverUrl = baseUrlInput.value.trim();
    const apiToken = apiTokenInput.value.trim();
    const defaultTags = defaultTagsInput.value.trim();
    const bookmarksPerPage = parseInt(bookmarksPerPageInput.value) || 20;
    const maxTagsDisplay = parseInt(maxTagsDisplayInput.value) || 20;
    const defaultUnread = defaultUnreadInput.checked;
    const defaultShared = defaultSharedInput.checked;
    const enableBookmarkComparison = enableBookmarkComparisonInput.checked;
    
    if (!serverUrl || !apiToken) {
      showStatus('请填写服务器URL和API令牌', 'error');
      return;
    }
    
    // 验证URL格式
    try {
      new URL(serverUrl);
    } catch (e) {
      showStatus('请输入有效的服务器URL', 'error');
      return;
    }
    
    // 保存到Chrome存储
    chrome.storage.sync.set({
      serverUrl: serverUrl,
      apiToken: apiToken,
      defaultTags: defaultTags,
      bookmarksPerPage: bookmarksPerPage,
      maxTagsDisplay: maxTagsDisplay,
      defaultUnread: defaultUnread,
      defaultShared: defaultShared,
      enableBookmarkComparison: enableBookmarkComparison
    }, function() {
      if (chrome.runtime.lastError) {
        showStatus('保存失败: ' + chrome.runtime.lastError.message, 'error');
      } else {
        showStatus('设置已保存', 'success');
        
        // 测试连接
        testConnection(serverUrl, apiToken);
      }
    });
  }
  
  // 测试连接
  function testConnection(serverUrl, apiToken) {
    const testUrl = new URL('/api/bookmarks/', serverUrl).href + '?limit=1';
    
    fetch(testUrl, {
      method: 'GET',
      headers: {
        'Authorization': 'Token ' + apiToken
      }
    })
    .then(response => {
      if (response.ok) {
        showStatus('连接测试成功！', 'success');
      } else {
        showStatus('连接测试失败，请检查URL和API令牌', 'error');
      }
    })
    .catch(error => {
      showStatus('连接测试失败: ' + error.message, 'error');
    });
  }
  
  // 显示状态消息
  function showStatus(message, type) {
    // 创建状态消息元素
    const statusDiv = document.createElement('div');
    statusDiv.className = type === 'error' ? 'error' : 'success';
    statusDiv.textContent = message;
    
    // 插入到页面顶部
    const container = document.querySelector('.container');
    container.insertBefore(statusDiv, container.firstChild);
    
    // 3秒后移除消息
    setTimeout(() => {
      statusDiv.remove();
    }, 3000);
  }
});