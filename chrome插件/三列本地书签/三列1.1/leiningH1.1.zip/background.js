// 后台脚本，用于处理插件的后台任务

// 监听安装事件
chrome.runtime.onInstalled.addListener(function(details) {
  if (details.reason === 'install') {
    // 首次安装时打开选项页面
    chrome.runtime.openOptionsPage();
  }
  
  // 创建右键菜单
  chrome.contextMenus.create({
    id: 'addBookmark',
    title: '添加到雷柠2.0横向插件书签',
    contexts: ['page', 'link']
  });
});

// 监听右键菜单点击事件
chrome.contextMenus.onClicked.addListener(function(info, tab) {
  if (info.menuItemId === 'addBookmark') {
    // 如果是链接上的右键点击，使用链接URL
    const url = info.linkUrl || info.pageUrl;
    openAddBookmarkPage(url);
  }
});

// 监听快捷键命令
chrome.commands.onCommand.addListener(function(command) {
  if (command === 'add_bookmark') {
    // 获取当前标签页
    chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
      if (tabs && tabs.length > 0) {
        openAddBookmarkPage(tabs[0].url);
      }
    });
  }
});

// 打开添加书签页面
function openAddBookmarkPage(url) {
  // 创建一个新的窗口来添加书签
  chrome.windows.create({
    url: chrome.runtime.getURL('add-bookmark.html'),
    type: 'popup',
    width: 400,
    height: 500
  });
}

// 监听浏览器按钮点击事件
chrome.action.onClicked.addListener(function(tab) {
  // 这个事件在manifest.json中设置了default_popup时不会触发
  // 但保留此代码以防将来需要更改行为
});