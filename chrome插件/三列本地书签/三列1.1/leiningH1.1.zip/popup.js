document.addEventListener('DOMContentLoaded', function() {
  // 页面切换相关
  const navItems = document.querySelectorAll('.nav-item');
  const pages = document.querySelectorAll('.page');
  
  // 书签列表相关
  let currentOffset = 0;
  let currentLimit = 20;
  let hasMoreBookmarks = true;
  let currentFilter = 'all';
  let currentSearchQuery = '';
  let isLoading = false;
  
  // DOM元素
  const bookmarksContainer = document.getElementById('bookmarksContainer');
  const loadMoreBtn = document.getElementById('loadMoreBtn');
  const searchInput = document.getElementById('searchInput');
  const filterButtons = document.querySelectorAll('.filter-btn');
  
  // 添加书签相关
  const bookmarkForm = document.getElementById('bookmarkForm');
  const urlInput = document.getElementById('url');
  const titleInput = document.getElementById('title');
  const tagsInput = document.getElementById('tags');
  const descInput = document.getElementById('descInput');
  const noteInput = document.getElementById('noteInput');
  const urlTip = document.getElementById('urlTip');
  const tagSuggestions = document.getElementById('tagSuggestions');
  
  // 设置相关
  const optionsForm = document.getElementById('optionsForm');
  const baseUrlInput = document.getElementById('baseUrl');
  const apiTokenInput = document.getElementById('apiToken');
  const defaultTagsInput = document.getElementById('defaultTags');
  const defaultUnreadInput = document.getElementById('defaultUnread');
  const defaultSharedInput = document.getElementById('defaultShared');
  const enableBookmarkComparisonInput = document.getElementById('enableBookmarkComparison');
  
  // 初始化
  init();
  
  function init() {
    setupNavigation();
    setupTabSwitching();
    loadSettings();
    
    // 检查设置并初始化相应页面
    checkSettings().then(hasSettings => {
      if (hasSettings) {
        loadCurrentPageInfo();
        setupBookmarkListEvents();
      }
    });
  }
  
  // 设置导航
  function setupNavigation() {
    navItems.forEach(item => {
      item.addEventListener('click', function() {
        const itemId = this.id;
        
        // 处理主页点击 - 在新标签页打开服务器URL
        if (itemId === 'homepageTab') {
          chrome.storage.sync.get(['serverUrl'], function(items) {
            if (items.serverUrl) {
              chrome.tabs.create({ url: items.serverUrl });
              window.close();
            } else {
              // 如果没有设置服务器URL，显示设置页面
              chrome.runtime.openOptionsPage();
              window.close();
            }
          });
          return;
        }
        
        // 处理本地主页点击 - 在当前标签页打开
        if (itemId === 'bookmarkListTab') {
          chrome.tabs.create({
            url: chrome.runtime.getURL('homepage.html')
          });
          window.close();
          return;
        }
        
        // 处理设置点击 - 使用options.page方式打开
        if (itemId === 'settingsTab') {
          chrome.runtime.openOptionsPage();
          window.close();
          return;
        }
        
        // 其他页面正常切换
        const targetPageId = this.id.replace('Tab', 'Page');
        switchToPage(targetPageId);
        
        // 更新导航状态
        navItems.forEach(nav => nav.classList.remove('active'));
        this.classList.add('active');
      });
    });
  }
  
  // 页面切换
  function switchToPage(pageId) {
    pages.forEach(page => page.classList.remove('active'));
    const targetPage = document.getElementById(pageId);
    if (targetPage) {
      targetPage.classList.add('active');
      
      // 根据页面执行特定初始化
      if (pageId === 'bookmarkListPage') {
        checkSettings().then(hasSettings => {
          if (hasSettings) {
            resetBookmarksList();
            loadBookmarks();
          } else {
            showNoSettingsMessage();
          }
        });
      } else if (pageId === 'settingsPage') {
        loadSettings();
      }
    }
  }
  
  // 设置选项卡切换
  function setupTabSwitching() {
    const tabs = document.querySelectorAll('.tab');
    const contents = document.querySelectorAll('.content');
    
    tabs.forEach(tab => {
      tab.addEventListener('click', function() {
        const targetType = this.dataset.type;
        
        // 更新选项卡状态
        tabs.forEach(t => t.classList.remove('active'));
        this.classList.add('active');
        
        // 更新内容显示
        contents.forEach(content => {
          content.classList.remove('active');
          if (content.id === targetType) {
            content.classList.add('active');
          }
        });
      });
    });
  }
  
  // 加载当前页面信息
  function loadCurrentPageInfo() {
    chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
      if (tabs && tabs.length > 0) {
        const currentTab = tabs[0];
        urlInput.value = currentTab.url;
        titleInput.value = currentTab.title;
        
        // 检查是否已存在该URL的书签
        checkExistingBookmark(currentTab.url);
      }
    });
  }
  
  // 检查现有书签
  function checkExistingBookmark(url) {
    chrome.storage.sync.get(['serverUrl', 'apiToken'], function(items) {
      if (!items.serverUrl || !items.apiToken) return;
      
      const apiUrl = new URL('/api/bookmarks/', items.serverUrl);
      apiUrl.searchParams.set('q', url);
      const finalUrl = apiUrl.href;
      
      fetch(finalUrl, {
        method: 'GET',
        headers: {
          'Authorization': 'Token ' + items.apiToken
        }
      })
      .then(response => response.json())
      .then(data => {
        if (data.results && data.results.length > 0) {
          const bookmark = data.results[0];
          // 填充现有书签信息
          titleInput.value = bookmark.title;
          tagsInput.value = bookmark.tag_names.join(' ');
          descInput.value = bookmark.description || '';
          noteInput.value = bookmark.notes || '';
          
          // 设置读取状态
          const readStatus = bookmark.is_archived ? 'read' : 'unread';
          document.querySelector(`input[name="readStatus"][value="${readStatus}"]`).checked = true;
          
          // 设置共享状态
          document.querySelector('input[name="shared"]').checked = bookmark.shared;
          
          // 显示提示
          urlTip.style.display = 'block';
        }
      })
      .catch(error => {
        console.error('检查现有书签失败:', error);
      });
    });
  }
  
  // 设置书签列表事件
  function setupBookmarkListEvents() {
    // 搜索输入事件
    if (searchInput) {
      searchInput.addEventListener('input', debounce(function() {
        currentSearchQuery = searchInput.value.trim();
        resetBookmarksList();
        loadBookmarks();
      }, 300));
    }
    
    // 加载更多按钮
    if (loadMoreBtn) {
      loadMoreBtn.addEventListener('click', function() {
        if (!isLoading && hasMoreBookmarks) {
          loadBookmarks(false);
        }
      });
    }
    
    // 过滤按钮
    filterButtons.forEach(button => {
      button.addEventListener('click', function() {
        filterButtons.forEach(btn => btn.classList.remove('active'));
        this.classList.add('active');
        
        currentFilter = this.dataset.filter;
        resetBookmarksList();
        loadBookmarks();
      });
    });
  }
  
  // 书签表单提交
  if (bookmarkForm) {
    bookmarkForm.addEventListener('submit', function(e) {
      e.preventDefault();
      submitBookmark();
    });
  }
  
  // 设置表单提交
  if (optionsForm) {
    optionsForm.addEventListener('submit', function(e) {
      e.preventDefault();
      saveSettings();
    });
  }
  
  // 提交书签
  function submitBookmark() {
    chrome.storage.sync.get(['serverUrl', 'apiToken'], function(items) {
      if (!items.serverUrl || !items.apiToken) {
        showError('请先配置服务器设置');
        return;
      }
      
      const formData = {
        url: urlInput.value,
        title: titleInput.value,
        description: descInput.value,
        notes: noteInput.value,
        tag_names: tagsInput.value.split(' ').filter(tag => tag.trim()),
        is_archived: document.querySelector('input[name="readStatus"]:checked').value === 'read',
        shared: document.querySelector('input[name="shared"]').checked
      };
      
      const apiUrl = new URL('/api/bookmarks/', items.serverUrl).href;
      
      fetch(finalUrl, {
        method: 'POST',
        headers: {
          'Authorization': 'Token ' + items.apiToken,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(formData)
      })
      .then(response => {
        if (!response.ok) {
          throw new Error('保存书签失败: ' + response.status);
        }
        return response.json();
      })
      .then(data => {
        showSuccess('书签保存成功!');
        // 清空表单或关闭窗口
        setTimeout(() => {
          window.close();
        }, 1000);
      })
      .catch(error => {
        console.error('保存书签失败:', error);
        showError(error.message);
      });
    });
  }
  
  // 保存设置
  function saveSettings() {
    const settings = {
      serverUrl: baseUrlInput.value.trim(),
      apiToken: apiTokenInput.value.trim(),
      defaultTags: defaultTagsInput.value.trim(),
      defaultUnread: defaultUnreadInput.checked,
      defaultShared: defaultSharedInput.checked,
      enableBookmarkComparison: enableBookmarkComparisonInput.checked
    };
    
    chrome.storage.sync.set(settings, function() {
      showSuccess('设置保存成功!');
    });
  }
  
  // 加载设置
  function loadSettings() {
    chrome.storage.sync.get([
      'serverUrl', 'apiToken', 'defaultTags', 
      'defaultUnread', 'defaultShared', 'enableBookmarkComparison'
    ], function(items) {
      if (baseUrlInput) baseUrlInput.value = items.serverUrl || '';
      if (apiTokenInput) apiTokenInput.value = items.apiToken || '';
      if (defaultTagsInput) defaultTagsInput.value = items.defaultTags || '';
      if (defaultUnreadInput) defaultUnreadInput.checked = items.defaultUnread || false;
      if (defaultSharedInput) defaultSharedInput.checked = items.defaultShared || false;
      if (enableBookmarkComparisonInput) enableBookmarkComparisonInput.checked = items.enableBookmarkComparison || false;
      
      // 显示服务器URL
      updateServerUrlDisplay(items.serverUrl);
    });
  }
  
  // 检查设置
  function checkSettings() {
    return new Promise(resolve => {
      chrome.storage.sync.get(['serverUrl', 'apiToken'], function(items) {
        resolve(items.serverUrl && items.apiToken);
      });
    });
  }
  
  // 重置书签列表
  function resetBookmarksList() {
    if (bookmarksContainer) {
      bookmarksContainer.innerHTML = '';
    }
    currentOffset = 0;
    hasMoreBookmarks = true;
    if (loadMoreBtn) {
      loadMoreBtn.style.display = 'none';
    }
  }
  
  // 加载书签
  function loadBookmarks(showLoading = true) {
    if (isLoading || !bookmarksContainer) return;
    isLoading = true;
    
    chrome.storage.sync.get(['serverUrl', 'apiToken'], function(items) {
      const { serverUrl, apiToken } = items;
      
      let apiUrl = new URL('/api/bookmarks/', serverUrl).href;
      const params = new URLSearchParams();
      params.append('limit', currentLimit.toString());
      params.append('offset', currentOffset.toString());
      
      if (currentSearchQuery) {
        params.append('q', currentSearchQuery);
      }
      
      if (currentFilter === 'archived') {
        apiUrl = new URL('/api/bookmarks/archived/', serverUrl).href;
      } else if (currentFilter === 'unread') {
        params.append('q', 'unread:true' + (currentSearchQuery ? ' ' + currentSearchQuery : ''));
      }
      
      apiUrl += '?' + params.toString();
      
      fetch(finalUrl, {
        method: 'GET',
        headers: {
          'Authorization': 'Token ' + apiToken
        }
      })
      .then(response => {
        if (!response.ok) {
          if (response.status === 404) {
            throw new Error('服务器地址不正确或API端点不存在 (404)');
          } else if (response.status === 401) {
            throw new Error('API令牌无效或已过期 (401)');
          } else if (response.status === 403) {
            throw new Error('没有访问权限 (403)');
          } else if (response.status >= 500) {
            throw new Error('服务器内部错误 (' + response.status + ')');
          } else {
            throw new Error('API请求失败: ' + response.status);
          }
        }
        return response.json();
      })
      .then(data => {
        if (data.results && data.results.length > 0) {
          renderBookmarks(data.results);
          currentOffset += data.results.length;
          hasMoreBookmarks = data.next !== null;
          if (loadMoreBtn) {
            loadMoreBtn.style.display = hasMoreBookmarks ? 'block' : 'none';
          }
        } else if (currentOffset === 0) {
          showNoResultsMessage();
        }
        isLoading = false;
      })
      .catch(error => {
        console.error('获取书签失败:', error);
        let errorMessage = error.message;
        if (error.name === 'TypeError' && error.message.includes('fetch')) {
          errorMessage = '无法连接到服务器，请检查服务器地址和网络连接';
        }
        showError(errorMessage + '\n\n请检查服务器地址和API令牌是否正确');
        isLoading = false;
      });
    });
  }
  
  // 渲染书签
  function renderBookmarks(bookmarks) {
    bookmarks.forEach(bookmark => {
      const bookmarkElement = document.createElement('div');
      bookmarkElement.className = 'bookmark-item';
      bookmarkElement.innerHTML = `
        <div class="bookmark-title">${bookmark.title}</div>
        <div class="bookmark-url">${bookmark.url}</div>
        <div class="bookmark-actions">
          <button onclick="window.open('${bookmark.url}', '_blank')">打开</button>
          <button onclick="editBookmark(${bookmark.id})">编辑</button>
        </div>
      `;
      bookmarksContainer.appendChild(bookmarkElement);
    });
  }
  
  // 显示错误信息
  function showError(message) {
    // 移除现有的错误提示
    const existingError = document.querySelector('.error');
    if (existingError) {
      existingError.remove();
    }
    
    const errorDiv = document.createElement('div');
    errorDiv.className = 'error';
    errorDiv.style.cssText = `
      position: fixed;
      top: 20px;
      left: 50%;
      transform: translateX(-50%);
      z-index: 9999;
      max-width: 400px;
      white-space: pre-line;
      box-shadow: 0 4px 12px rgba(0,0,0,0.15);
    `;
    errorDiv.textContent = message;
    document.body.appendChild(errorDiv);
    
    setTimeout(() => {
      if (errorDiv.parentNode) {
        errorDiv.remove();
      }
    }, 8000);
  }
  
  // 显示成功信息
  function showSuccess(message) {
    const successDiv = document.createElement('div');
    successDiv.className = 'success';
    successDiv.textContent = message;
    document.body.insertBefore(successDiv, document.body.firstChild);
    
    setTimeout(() => {
      successDiv.remove();
    }, 3000);
  }
  
  // 显示无设置消息
  function showNoSettingsMessage() {
    if (bookmarksContainer) {
      bookmarksContainer.innerHTML = '<div class="error">请先配置服务器设置</div>';
    }
  }
  
  // 显示无结果消息
  function showNoResultsMessage() {
    if (bookmarksContainer) {
      bookmarksContainer.innerHTML = '<div>没有找到书签</div>';
    }
  }
  
  // 防抖函数
  function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
      const later = () => {
        clearTimeout(timeout);
        func(...args);
      };
      clearTimeout(timeout);
      timeout = setTimeout(later, wait);
    };
  }
  
  // 更新服务器URL显示
  function updateServerUrlDisplay(serverUrl) {
    const serverUrlDisplay = document.getElementById('serverUrlDisplay');
    const homepageTab = document.getElementById('homepageTab');
    
    if (serverUrl && serverUrlDisplay && homepageTab) {
      try {
        const url = new URL(serverUrl);
        const hostname = url.hostname;
        serverUrlDisplay.textContent = `主页${hostname}`;
        homepageTab.style.display = 'inline-block';
        
        // 检测连接状态
        checkServerConnection(serverUrl, hostname);
      } catch (e) {
        homepageTab.style.display = 'none';
      }
    } else if (homepageTab) {
      homepageTab.style.display = 'none';
    }
  }
  
  // 检测服务器连接状态
  function checkServerConnection(serverUrl, hostname) {
    const serverUrlDisplay = document.getElementById('serverUrlDisplay');
    if (!serverUrlDisplay) return;
    
    chrome.storage.sync.get(['apiToken'], function(items) {
      if (!items.apiToken) {
        serverUrlDisplay.textContent = `主页${hostname} (未配置令牌)`;
        serverUrlDisplay.style.color = '#ff6b6b';
        return;
      }
      
      // 测试API连接
      const apiUrl = new URL('/api/bookmarks/?limit=1', serverUrl).href;
      fetch(finalUrl, {
        method: 'GET',
        headers: {
          'Authorization': 'Token ' + items.apiToken
        }
      })
      .then(response => {
        if (response.ok) {
          serverUrlDisplay.textContent = `主页${hostname} (已连接)`;
          serverUrlDisplay.style.color = '#007bff';
        } else {
          serverUrlDisplay.textContent = `主页${hostname} (连接失败)`;
          serverUrlDisplay.style.color = '#ff6b6b';
        }
      })
      .catch(error => {
        serverUrlDisplay.textContent = `主页${hostname} (无法连接)`;
        serverUrlDisplay.style.color = '#ff6b6b';
      });
    });
  }
});